# HEX-REC — enregistreur d'écran Android

Enregistre l'écran avec une bulle webcam ronde, découpe, rend en MP4 H.264 1080p et publie sur ton VPS (`/v/<id>`). Sans compte ni télémétrie.

## L'accueil

- **Raccourcis ronds** : *Brosse*, *Caméra faciale*, *Capture d'écran*, *Balle flottante* (rouge = actif).
- **Vidéo** : tes enregistrements avec miniature, durée et état (rendu / publié), plus l'espace de stockage utilisé. Appui long = supprimer.
- **Enregistrer** : gros bouton en bas. Un décompte, puis l'appli passe en arrière-plan.
- **Barre du bas** : Vidéo · Photo · **+** · Modifier · Paramètres.
  - **+** : enregistrer, capture d'écran, importer une vidéo de la galerie.

## Pendant l'enregistrement

- **Bulle webcam** (bas à gauche, déplaçable) : capturée avec l'écran.
- **Balle flottante** : touche-la pour ouvrir les outils : pause/reprise, arrêt, **brosse** (dessin à l'écran), couleur, effacer. Tu peux aussi utiliser la notification (Pause / Arrêter).
  - La balle et ses outils sont des fenêtres système : ils apparaissent dans la vidéo tant qu'ils sont visibles. Replie le panneau (retouche la balle) ou désactive la balle dans Paramètres si tu ne veux pas la voir.

## Montage et publication

Touche l'enregistrement (ou la notification « terminé ») :

1. Modifie le **titre**.
2. Glisse les poignées de la chronologie, ou place la lecture puis *Entrée ici* / *Sortie ici*. *Prévisualiser* joue seulement la sélection.
3. **Rendre en MP4 1080p** : le petit côté fait 1080 px, ratio conservé (1080×1920 en portrait).
4. **Publier** : envoi SFTP sur ton VPS, lien copié dans le presse-papiers. *Enregistrer dans la galerie* copie le rendu dans Films/HEX-REC.

## Paramètres

Résolution (1080p/720p/480p), images par seconde (30/60), qualité (standard/élevée), décompte (aucun/3/5/10 s), micro, bulle webcam et sa taille, balle flottante, brosse, **Serveur de partage** (SFTP). Touche une ligne pour changer sa valeur.

### Serveur de partage

URL de partage, serveur, port, utilisateur, dossier distant (`/srv/share/data`), puis mot de passe **ou** clé privée. Pour une clé, préfère RSA ou ECDSA (`ssh-keygen -t rsa -b 4096 -m PEM`) : les clés ed25519 peuvent ne pas être lues sur Android. *Tester la connexion* vérifie tout. La clé du serveur est mémorisée à la première connexion, puis vérifiée.

Côté VPS : l'appli de partage + Caddy de la version bureau (`vps/share`). Format reçu : `<id>/video.mp4`, `poster.jpg`, `meta.json`.

## Fichiers

- Vidéos : `Android/data/app.hexrec/files/Movies/Recordings/AAAA-MM-JJ-<titre>/` (`original.mp4`, `final.mp4`, `poster.jpg`, `meta.json`, `publish.json`).
- Captures : `Android/data/app.hexrec/files/Pictures/Screenshots/`, avec une copie dans Images/HEX-REC.

## Compiler l'APK avec GitHub

1. Crée un dépôt, envoie `HEX-REC-Android.zip` à la racine (sans le dézipper).
2. Ajoute `build.yml` dans `.github/workflows/build.yml`.
3. Actions → *Construire l'APK HEX-REC* → *Run workflow* (aussi à chaque push sur `main`).
4. L'APK arrive dans **Releases** (`app-debug.apk`).

À la main : `gradle assembleDebug` dans `HEX-REC/` (JDK 17, Android SDK 34, Gradle 8.9).

## Limites

- Android 11 minimum.
- Le son enregistré est celui du **micro** : l'audio interne des applis n'est pas capturé.
- Ne fais pas pivoter l'écran pendant l'enregistrement.
- Les applis qui bloquent la capture (banque, DRM) apparaissent en noir.
- Le rendu 1080p se fait sur le téléphone : garde l'appli ouverte (et branche-le pour les longues vidéos).
- Mot de passe et clé SSH stockés dans le stockage privé de l'appli, non chiffrés.
- Le code n'a pas pu être compilé ni testé sur un appareil. Si le premier build échoue, envoie l'erreur du journal Actions pour la corriger.
