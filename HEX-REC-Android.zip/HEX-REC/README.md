# HEX-REC — enregistreur d'écran Android

Enregistre l'écran avec une bulle webcam ronde, découpe, rend en MP4 H.264 et publie sur ton VPS (`/v/<id>`). Sans compte ni télémétrie.

## L'accueil

- **Raccourcis ronds** : Brosse, Caméra faciale, Capture d'écran, Bouton flottant (rouge = actif).
- **Vidéo** : tes enregistrements avec miniature, durée et état (rendu / publié), plus l'espace utilisé. Appui long = supprimer.
- **Enregistrer** : gros bouton en bas. Décompte, puis l'appli passe en arrière-plan.
- **Barre du bas** : Vidéo · Photo · **+** · Modifier · Paramètres. Le **+** : enregistrer, capture d'écran, importer une vidéo.

## Le bouton flottant (pause, arrêt, brosse)

Une pastille rouge **avec le chrono** apparaît pendant l'enregistrement. Déplace-la au doigt, touche-la pour ouvrir le panneau :

| Bouton | Action |
|---|---|
| ⏸ / ▶ | Pause / reprise (la pastille devient orange en pause) |
| ■ | Arrêter l'enregistrement |
| Brosse | Dessiner à l'écran |
| Couleur | Rouge, jaune, blanc, bleu |
| Corbeille | Effacer le dessin |

Pause et arrêt existent aussi dans la notification (avec chrono). Le bouton flottant est une fenêtre système : il apparaît dans la vidéo tant qu'il est visible (il est semi-transparent quand le panneau est fermé). Désactive-le dans Paramètres si tu ne veux pas le voir.

## Fonctions

- Bulle webcam (bas à gauche, déplaçable), caméra avant ou arrière, 3 tailles.
- Capture d'écran (onglet Photo + galerie), partage des captures.
- Import d'une vidéo de la galerie pour la découper et la publier.
- Montage : poignées entrée/sortie, prévisualisation de la sélection, rendu MP4 en **1080p ou 720p**.
- **Partager** la vidéo ou le lien publié, copie dans la galerie.
- **Limite de durée** (5 / 10 / 30 min / 1 h), **secouer deux fois pour arrêter** (selon les téléphones).
- Résolution (1080/720/480p), 30 ou 60 images/s, qualité standard ou élevée, décompte, micro.

## Paramètres → CENTRAL-HEX

Page de présentation de la communauté CENTRAL-HEX (tech, IA, bots, automatisation, ressources, mission), avec :

- Créateur : **Ibrahima Sory Sacko** · Pseudo : **SALGADO**
- E-mail : **centralhex224@gmail.com** (écrire / copier)
- Chaîne WhatsApp : https://whatsapp.com/channel/0029VbC8YkY7oQhiOiiSpy1z (rejoindre / partager)

## Serveur de partage (SFTP)

Paramètres → Serveur de partage : URL de partage, serveur, port, utilisateur, dossier distant (`/srv/share/data`), puis mot de passe **ou** clé privée (préfère RSA/ECDSA : `ssh-keygen -t rsa -b 4096 -m PEM` ; ed25519 peut ne pas être lu sur Android). *Tester la connexion* vérifie tout. La clé du serveur est mémorisée à la première connexion, puis vérifiée. Côté VPS : l'appli de partage + Caddy de la version bureau (`vps/share`).

## Fichiers

- Vidéos : `Android/data/app.hexrec/files/Movies/Recordings/AAAA-MM-JJ-<titre>/` (`original.mp4`, `final.mp4`, `poster.jpg`, `meta.json`, `publish.json`).
- Captures : `Android/data/app.hexrec/files/Pictures/Screenshots/` (copie dans Images/HEX-REC).

## Compiler l'APK avec GitHub

1. Dépôt GitHub : envoie `HEX-REC-Android.zip` à la racine (sans le dézipper).
2. Ajoute `build.yml` dans `.github/workflows/build.yml`.
3. Actions → *Construire l'APK HEX-REC* → *Run workflow*.
4. L'APK arrive dans **Releases** (`app-debug.apk`).

À la main : `gradle assembleDebug` dans `HEX-REC/` (JDK 17, Android SDK 34, Gradle 8.9).

## Limites

- Android 11 minimum. Le son enregistré est celui du **micro** (pas l'audio interne).
- Ne fais pas pivoter l'écran pendant l'enregistrement.
- Les applis qui bloquent la capture (banque, DRM) apparaissent en noir.
- Le rendu se fait sur le téléphone : garde l'appli ouverte.
- Mot de passe et clé SSH stockés dans le stockage privé de l'appli, non chiffrés.
- Le code n'a pas pu être compilé ni testé sur un appareil. Si le build échoue, envoie l'erreur du journal Actions.
