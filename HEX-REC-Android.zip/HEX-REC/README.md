# HEX-REC — enregistreur d'écran Android

Noir et blanc. Enregistre l'écran avec une bulle webcam ronde, découpe, rend en MP4 H.264, exporte en GIF ou en version WhatsApp, et publie sur ton VPS (`/v/<id>`). Sans compte ni télémétrie.

## L'accueil

- **En-tête** HEX-REC avec le logo et la date, **statistiques** (vidéos, minutes, publiées).
- **Raccourcis** : Brosse, Caméra faciale, Capture, Bouton flottant (plein = actif).
- **Profils d'enregistrement** en un toucher : Tuto, Jeu (60 i/s), Présentation, Léger.
- **Plus d'outils** : Importer, GIF, WhatsApp, CENTRAL-HEX.
- **Vidéo** : miniatures, durée, état, jauge de stockage ; **Captures d'écran** ; **dernier lien publié** (copier / partager) ; **astuce du jour** ; carte **CENTRAL-HEX**.
- **Enregistrer** : gros bouton en bas. Barre du bas : Vidéo · Photo · **+** · Modifier · Réglages.

## Le bouton flottant

Pastille avec **chrono** pendant l'enregistrement : déplace-la, touche-la pour ouvrir pause/reprise, arrêt, brosse, couleur, effacer. Pause et arrêt sont aussi dans la notification. Elle apparaît dans la vidéo tant qu'elle est visible (semi-transparente panneau fermé) ; désactive-la dans Réglages si besoin.

## Montage

- **Découpe** : poignées entrée/sortie, prévisualisation de la sélection.
- **Plusieurs coupes** : « + Ajouter ce passage » pour chaque morceau à garder ; le rendu les assemble dans l'ordre.
- **Accélérer / ralentir** : 0,5× à 3× (image et son).
- **Filigrane HEX-REC** (logo + nom en haut à droite) activable/désactivable.
- **Rendu MP4** en 1080p ou 720p (réglage).
- **Exporter en GIF** (10 i/s, 15 s max, 400 px) avec aperçu animé.
- **Image d'affiche** : choisis l'image du lien partagé avec le curseur.
- **Compresser pour WhatsApp** : version sous 16 Mo (débit calculé selon la durée).
- **Publier**, partager le lien ou la vidéo, enregistrer dans la galerie.

## Tuile « Réglages rapides »

Glisse le panneau de notifications → crayon (modifier) → fais glisser **HEX-REC** dans tes tuiles. Un toucher démarre l'enregistrement (l'appli s'ouvre pour l'autorisation de capture), un autre l'arrête.

## Réglages

Résolution, images/s, qualité, décompte, micro, limite de durée, secouer pour arrêter, bulle (activée, taille, caméra), bouton flottant, brosse, résolution du rendu, filigrane, **thème Noir / Blanc**, serveur de partage (SFTP), **CENTRAL-HEX**.

## CENTRAL-HEX

Communauté Tech & Digital : tech et IA, bots, automatisation, ressources, mission.
Créateur : Ibrahima Sory Sacko · Pseudo : SALGADO · centralhex224@gmail.com
Chaîne : https://whatsapp.com/channel/0029VbDCmVWISTkNEy1D3p3H

## Serveur de partage

Réglages → Serveur de partage : URL, serveur, port, utilisateur, dossier distant (`/srv/share/data`), mot de passe **ou** clé privée (RSA/ECDSA : `ssh-keygen -t rsa -b 4096 -m PEM`). *Tester la connexion* vérifie tout.

Côté VPS : dossier `vps/share` (appli Node + Caddy + service systemd). La page `/v/<id>` est en noir et blanc, typographie soignée, et ne montre que le lecteur, le titre et ton nom. Installation : voir `vps/share/` (copie avec `rsync`, `npm install --omit=dev`, `share.service`, `Caddyfile`).

## Compiler l'APK avec GitHub

1. Dépôt GitHub : `HEX-REC-Android.zip` à la racine (sans le dézipper).
2. `build.yml` dans `.github/workflows/build.yml`.
3. Actions → *Construire l'APK HEX-REC* → *Run workflow*.
4. L'APK arrive dans **Releases** (`app-debug.apk`).

## Limites

- Android 11 minimum. Son = micro (pas l'audio interne).
- Ne fais pas pivoter l'écran pendant l'enregistrement.
- Applis qui bloquent la capture (banque, DRM) : image noire.
- Rendu, GIF et compression se font sur le téléphone : garde l'appli ouverte.
- Plusieurs coupes : les passages sont rendus un par un puis assemblés sans ré-encodage.
- Le code n'a pas pu être compilé ni testé sur un appareil. Si le build échoue, envoie l'erreur du journal Actions.
