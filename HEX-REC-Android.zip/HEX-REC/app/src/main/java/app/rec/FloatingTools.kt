package app.rec

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale
import kotlin.math.abs

/** Surface de dessin plein écran (la « brosse »). */
class DrawView(ctx: Context) : View(ctx) {
    private class Stroke(val path: Path, val paint: Paint)

    private val strokes = ArrayList<Stroke>()
    private var cur: Stroke? = null
    private val strokeW = 5 * resources.displayMetrics.density
    var penColor = 0xFFFF2D2D.toInt()

    override fun onDraw(canvas: Canvas) {
        for (s in strokes) canvas.drawPath(s.path, s.paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val p = Path()
                p.moveTo(e.x, e.y)
                p.lineTo(e.x + 0.1f, e.y + 0.1f)
                val paint = Paint(Paint.ANTI_ALIAS_FLAG)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = strokeW
                paint.strokeCap = Paint.Cap.ROUND
                paint.strokeJoin = Paint.Join.ROUND
                paint.color = penColor
                val s = Stroke(p, paint)
                strokes.add(s)
                cur = s
            }
            MotionEvent.ACTION_MOVE -> cur?.path?.lineTo(e.x, e.y)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> cur = null
        }
        invalidate()
        return true
    }

    fun clear() {
        strokes.clear()
        invalidate()
    }
}

/**
 * Bouton flottant d'enregistrement : une pastille déplaçable qui affiche le chrono.
 * Un toucher ouvre le panneau : pause/reprise, arrêt, brosse, couleur, effacer.
 * C'est une fenêtre système : elle apparaît aussi dans la vidéo tant qu'elle est visible
 * (elle est semi-transparente quand le panneau est fermé).
 */
class FloatingTools(
    private val ctx: Context,
    private val wm: WindowManager,
    private val brush: Boolean,
    private val onTogglePause: () -> Boolean,
    private val onStop: () -> Unit
) {
    private val d = ctx.resources.displayMetrics.density
    private fun dp(v: Int) = (v * d).toInt()

    private val red = 0xFFE5231B.toInt()
    private val amber = 0xFFFF9500.toInt()
    private val handler = Handler(Looper.getMainLooper())
    private val startMs = SystemClock.elapsedRealtime()
    private var pausedAt = 0L
    private var pausedTotal = 0L
    private var paused = false

    private var root: LinearLayout? = null
    private var lp: WindowManager.LayoutParams? = null
    private var ball: TextView? = null
    private var panel: LinearLayout? = null
    private var draw: DrawView? = null
    private var drawLp: WindowManager.LayoutParams? = null
    private var pauseBtn: ImageView? = null
    private var penBtn: ImageView? = null
    private var colorBtn: ImageView? = null
    private var penOn = false
    private var colorIdx = 0
    private val colors = intArrayOf(0xFFFF2D2D.toInt(), 0xFFFFD60A.toInt(), 0xFFFFFFFF.toInt(), 0xFF2D9CFF.toInt())

    private val clockTick = object : Runnable {
        override fun run() {
            updateBall()
            handler.postDelayed(this, 500)
        }
    }

    private fun elapsed(): Long {
        val now = SystemClock.elapsedRealtime()
        return (if (pausedAt > 0L) pausedAt else now) - startMs - pausedTotal
    }

    private fun updateBall() {
        val b = ball ?: return
        val s = (elapsed() / 1000).coerceAtLeast(0L)
        b.text = if (s >= 3600) {
            String.format(Locale.ROOT, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
        } else {
            String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60)
        }
        b.textSize = if (s >= 3600) 10f else 13f
    }

    /** Synchronise l'état « pause » (appelé aussi depuis la notification). Idempotent. */
    fun syncPaused(p: Boolean) {
        val now = SystemClock.elapsedRealtime()
        if (p && pausedAt == 0L) pausedAt = now
        if (!p && pausedAt > 0L) { pausedTotal += now - pausedAt; pausedAt = 0L }
        paused = p
        pauseBtn?.setImageResource(if (p) R.drawable.ic_play else R.drawable.ic_pause)
        (ball?.background as? GradientDrawable)?.setColor(if (p) 0xFFFFFFFF.toInt() else 0xFF000000.toInt())
        ball?.setTextColor(if (p) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
        updateBall()
    }

    private fun circle(fill: Int, iconRes: Int, tint: Int, sizeDp: Int): ImageView = ImageView(ctx).apply {
        setImageResource(iconRes)
        setColorFilter(tint)
        val pad = dp(sizeDp / 4)
        setPadding(pad, pad, pad, pad)
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(fill) }
    }

    fun show() {
        val b = TextView(ctx).apply {
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 13f
            setTypeface(typeface, Typeface.BOLD)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF000000.toInt()); setStroke(dp(2), 0xFFFFFFFF.toInt()) }
            alpha = 0.65f
        }
        ball = b

        val p = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        fun addBtn(v: ImageView, onTap: () -> Unit) {
            v.setOnClickListener { onTap() }
            p.addView(v, LinearLayout.LayoutParams(dp(44), dp(44)).apply { topMargin = dp(8); leftMargin = dp(5) })
        }
        pauseBtn = circle(0xFFFFFFFF.toInt(), R.drawable.ic_pause, 0xFF111214.toInt(), 44)
        addBtn(pauseBtn!!) {
            val now = onTogglePause()
            syncPaused(now)
        }
        addBtn(circle(red, R.drawable.ic_stop, 0xFFFFFFFF.toInt(), 44)) { onStop() }
        if (brush) {
            penBtn = circle(0xFFFFFFFF.toInt(), R.drawable.ic_brush, 0xFF111214.toInt(), 44)
            addBtn(penBtn!!) { setPen(!penOn) }
            colorBtn = circle(colors[0], R.drawable.ic_add, colors[0], 44)
            addBtn(colorBtn!!) {
                colorIdx = (colorIdx + 1) % colors.size
                draw?.penColor = colors[colorIdx]
                (colorBtn?.background as? GradientDrawable)?.setColor(colors[colorIdx])
                colorBtn?.setColorFilter(colors[colorIdx])
            }
            addBtn(circle(0xFFFFFFFF.toInt(), R.drawable.ic_delete, 0xFF111214.toInt(), 44)) { draw?.clear() }
        }
        panel = p

        val r = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        r.addView(b, LinearLayout.LayoutParams(dp(54), dp(54)))
        r.addView(p, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        root = r

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = ctx.resources.displayMetrics.widthPixels - dp(66)
            y = ctx.resources.displayMetrics.heightPixels / 3
        }
        lp = params

        b.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f
            var sy = 0f
            var ox = 0
            var oy = 0
            var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = params.x; oy = params.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        if (abs(e.rawX - sx) > dp(8) || abs(e.rawY - sy) > dp(8)) moved = true
                        if (moved) {
                            params.x = ox + (e.rawX - sx).toInt()
                            params.y = oy + (e.rawY - sy).toInt()
                            try { wm.updateViewLayout(r, params) } catch (x: Exception) { }
                        }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) {
                        val open = p.visibility != View.VISIBLE
                        p.visibility = if (open) View.VISIBLE else View.GONE
                        b.alpha = if (open) 1f else 0.65f
                    }
                }
                return true
            }
        })
        wm.addView(r, params)
        updateBall()
        handler.postDelayed(clockTick, 500)
    }

    private fun setPen(on: Boolean) {
        penOn = on
        val r = root ?: return
        if (draw == null) {
            val dv = DrawView(ctx)
            dv.penColor = colors[colorIdx]
            draw = dv
            val dl = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            drawLp = dl
            wm.addView(dv, dl)
            // le bouton doit rester au-dessus de la couche de dessin
            try { wm.removeView(r); wm.addView(r, lp) } catch (e: Exception) { }
        }
        val dl = drawLp ?: return
        dl.flags = if (on) {
            dl.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            dl.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        try { wm.updateViewLayout(draw, dl) } catch (e: Exception) { }
        (penBtn?.background as? GradientDrawable)?.setColor(if (on) 0xFFFFD60A.toInt() else 0xFFFFFFFF.toInt())
    }

    fun hide() {
        handler.removeCallbacks(clockTick)
        try { root?.let { wm.removeView(it) } } catch (e: Exception) { }
        try { draw?.let { wm.removeView(it) } } catch (e: Exception) { }
        root = null
        draw = null
        ball = null
    }
}
