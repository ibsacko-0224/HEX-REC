package app.rec

/** Palette noir & blanc. Le rouge n'est utilisé que pour le point « REC » et les erreurs. */
object Pal {
    var dark = true
    var bg = 0
    var panel = 0
    var line = 0
    var fg = 0
    var mut = 0
    var acc = 0
    var onAcc = 0
    const val ok = 0xFF1E9E5A.toInt()
    const val err = 0xFFE5231B.toInt()
    const val rec = 0xFFFF2D2D.toInt()
    const val white = 0xFFFFFFFF.toInt()
    const val black = 0xFF000000.toInt()

    fun apply(isDark: Boolean) {
        dark = isDark
        if (isDark) {
            bg = 0xFF000000.toInt(); panel = 0xFF151515.toInt(); line = 0xFF2B2B2B.toInt()
            fg = 0xFFF5F5F5.toInt(); mut = 0xFF8E8E93.toInt(); acc = 0xFFFFFFFF.toInt(); onAcc = 0xFF000000.toInt()
        } else {
            bg = 0xFFFFFFFF.toInt(); panel = 0xFFF2F2F2.toInt(); line = 0xFFE2E2E2.toInt()
            fg = 0xFF0A0A0A.toInt(); mut = 0xFF6B6B70.toInt(); acc = 0xFF0A0A0A.toInt(); onAcc = 0xFFFFFFFF.toInt()
        }
    }

    init { apply(true) }
}
