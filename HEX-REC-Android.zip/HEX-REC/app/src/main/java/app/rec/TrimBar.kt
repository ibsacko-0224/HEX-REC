package app.rec

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

/** Chronologie simple : deux poignées (entrée / sortie) + tête de lecture. */
class TrimBar(ctx: Context) : View(ctx) {
    var duration = 0L
    var start = 0L
    var end = 0L
    var position = 0L

    /** 1 = poignée d'entrée, 2 = poignée de sortie, 3 = déplacement de la lecture */
    var onDrag: ((Int) -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var mode = 0
    private val pad = 16 * d
    private val minGap = 200L
    private var cTrack = 0xFFE2E2E2.toInt()
    private var cRange = 0x330A0A0A
    private var cHandle = 0xFF0A0A0A.toInt()
    private var cHead = 0xFF0A0A0A.toInt()

    fun applyColors(track: Int, handle: Int, head: Int) {
        cTrack = track
        cHandle = handle
        cHead = head
        cRange = (handle and 0x00FFFFFF) or 0x40000000
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(resolveSize(suggestedMinimumWidth, widthMeasureSpec), (64 * d).toInt())
    }

    private fun xOf(t: Long): Float =
        pad + (width - 2 * pad) * (if (duration > 0) t.toFloat() / duration else 0f)

    private fun tOf(x: Float): Long =
        (((x - pad) / (width - 2 * pad)).coerceIn(0f, 1f) * duration).toLong()

    override fun onDraw(canvas: Canvas) {
        val top = 14 * d
        val bottom = height - 14 * d
        paint.style = Paint.Style.FILL
        paint.color = cTrack
        canvas.drawRoundRect(pad, top, width - pad, bottom, 6 * d, 6 * d, paint)
        if (duration <= 0) return

        val xs = xOf(start)
        val xe = xOf(end)
        paint.color = cRange
        canvas.drawRect(xs, top, xe, bottom, paint)
        paint.color = cHandle
        canvas.drawRect(xs, top, xe, top + 2 * d, paint)
        canvas.drawRect(xs, bottom - 2 * d, xe, bottom, paint)
        for (x in floatArrayOf(xs, xe)) {
            canvas.drawRoundRect(x - 6 * d, 6 * d, x + 6 * d, height - 6 * d, 3 * d, 3 * d, paint)
        }
        paint.color = cHead
        val xp = xOf(position)
        canvas.drawRect(xp - d, 8 * d, xp + d, height - 8 * d, paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (duration <= 0) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val ds = abs(e.x - xOf(start))
                val de = abs(e.x - xOf(end))
                mode = if (minOf(ds, de) < 28 * d) (if (ds <= de) 1 else 2) else 3
                move(e.x)
            }
            MotionEvent.ACTION_MOVE -> move(e.x)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> mode = 0
        }
        return true
    }

    private fun move(x: Float) {
        val t = tOf(x)
        when (mode) {
            1 -> start = minOf(t, end - minGap).coerceAtLeast(0L)
            2 -> end = maxOf(t, start + minGap).coerceAtMost(duration)
            3 -> position = t
        }
        invalidate()
        onDrag?.invoke(mode)
    }
}
