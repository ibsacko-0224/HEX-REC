package app.rec

import android.content.Context
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Locale

/* Petits outils d'interface (polices Roboto : black / medium / regular, interlettrage soigné). */

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.font(family: String): Typeface = Typeface.create(family, Typeface.NORMAL)

fun Context.label(s: String, size: Float = 15f, color: Int = Pal.fg, bold: Boolean = false): TextView =
    TextView(this).apply {
        text = s
        textSize = size
        setTextColor(color)
        typeface = font(if (bold) "sans-serif-medium" else "sans-serif")
    }

/** Titre : majuscules, graisse « black », interlettrage large. */
fun Context.heading(s: String, size: Float = 26f, color: Int = Pal.fg): TextView =
    TextView(this).apply {
        text = s.uppercase(Locale.ROOT)
        textSize = size
        setTextColor(color)
        typeface = font("sans-serif-black")
        letterSpacing = 0.04f
    }

/** Petit intitulé de section. */
fun Context.caption(s: String, color: Int = Pal.mut): TextView =
    TextView(this).apply {
        text = s.uppercase(Locale.ROOT)
        textSize = 11f
        setTextColor(color)
        typeface = font("sans-serif-medium")
        letterSpacing = 0.18f
    }

fun Context.roundBg(color: Int, r: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        cornerRadius = dp(r).toFloat()
        setColor(color)
        if (strokeDp > 0) setStroke(dp(strokeDp), strokeColor)
    }

fun Context.ovalBg(color: Int, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
        if (strokeDp > 0) setStroke(dp(strokeDp), strokeColor)
    }

fun Context.icon(res: Int, tint: Int, size: Int = 24): ImageView =
    ImageView(this).apply {
        setImageResource(res)
        setColorFilter(tint)
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
    }

fun Context.rounded(r: Int): ViewOutlineProvider {
    val px = dp(r).toFloat()
    return object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, px)
        }
    }
}

/** Bouton : principal = plein (noir ou blanc selon le thème), sinon contour fin. */
fun Context.button(s: String, primary: Boolean = false, onClick: () -> Unit): TextView =
    TextView(this).apply {
        text = s
        textSize = 14f
        gravity = Gravity.CENTER
        typeface = font("sans-serif-medium")
        letterSpacing = 0.03f
        setTextColor(if (primary) Pal.onAcc else Pal.fg)
        background = if (primary) roundBg(Pal.acc, 26) else roundBg(Pal.panel, 26, Pal.line, 1)
        setPadding(dp(14), dp(14), dp(14), dp(14))
        setOnClickListener { onClick() }
    }

fun Context.column(): LinearLayout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

fun Context.row(vararg v: View): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.HORIZONTAL
    v.forEachIndexed { i, x ->
        addView(x, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
            if (i > 0) leftMargin = dp(8)
        })
    }
}

fun Context.pageScroll(c: LinearLayout, bottomPad: Int = 30): ScrollView = ScrollView(this).apply {
    setBackgroundColor(Pal.bg)
    c.setPadding(dp(18), dp(20), dp(18), dp(bottomPad))
    addView(c)
}

fun LinearLayout.add(v: View, top: Int = 10, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT): View {
    addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h).apply { topMargin = context.dp(top) })
    return v
}
