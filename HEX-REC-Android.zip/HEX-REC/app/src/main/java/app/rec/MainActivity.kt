package app.rec

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.ColorDrawable
import android.media.MediaMetadataRetriever
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsetsController
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {

    companion object {
        const val REQ_PERMS = 1
        const val REQ_PROJ = 2
        const val REQ_IMPORT = 3
        const val ACT_RECORD = 0
        const val ACT_SHOT = 1
        const val CH_LINK = "https://whatsapp.com/channel/0029VbDCmVWISTkNEy1D3p3H"
        const val EMAIL = "centralhex224@gmail.com"
        val TIPS = listOf(
            "Touche la pastille flottante pour mettre en pause sans arrêter la vidéo.",
            "Active « Secouer pour arrêter » dans Paramètres pour stopper d'un geste.",
            "« Compresser pour WhatsApp » ramène ta vidéo sous 16 Mo.",
            "Plusieurs coupes : ajoute chaque passage à garder, le rendu les assemble.",
            "Choisis une belle image d'affiche avant de publier : c'est l'aperçu du lien.",
            "Ajoute la tuile HEX-REC aux réglages rapides pour démarrer en un geste.",
            "La brosse te laisse dessiner à l'écran pendant l'enregistrement.",
            "Profil « Jeu » : 60 images/s et qualité élevée."
        )
    }

    private lateinit var prefs: Prefs
    private val ui = Handler(Looper.getMainLooper())

    // structure
    private lateinit var content: FrameLayout
    private lateinit var nav: LinearLayout
    private val navIcons = ArrayList<ImageView>()
    private val navLabels = ArrayList<TextView>()
    private lateinit var pgHome: FrameLayout
    private lateinit var pgPhotos: ScrollView
    private lateinit var pgTools: ScrollView
    private lateinit var pgSettings: ScrollView
    private lateinit var pgEditor: ScrollView
    private lateinit var pgPub: ScrollView
    private lateinit var pgAbout: ScrollView
    private var tab = 0
    private var pendingAction = ACT_RECORD

    // accueil
    private class Shortcut(val circle: FrameLayout, val icon: ImageView, val active: () -> Boolean)
    private val shortcuts = ArrayList<Shortcut>()
    private val presetViews = ArrayList<Pair<String, TextView>>()
    private lateinit var statVideos: TextView
    private lateinit var statMinutes: TextView
    private lateinit var statPublished: TextView
    private lateinit var homeDyn: LinearLayout
    private lateinit var pillText: TextView
    private lateinit var toolsList: LinearLayout
    private lateinit var photosBox: LinearLayout

    // montage
    private var dir: File? = null
    private var dur = 0L
    private var previewing = false
    private var busy = false
    private var transformer: Transformer? = null
    private var publishedUrl: String? = null
    private var speed = 1f
    private val segments = ArrayList<LongArray>()
    private var finalDurMs = 0L
    private var pendingPoster: Bitmap? = null
    private lateinit var titleEdit: EditText
    private lateinit var video: VideoView
    private lateinit var trim: TrimBar
    private lateinit var times: TextView
    private lateinit var playBtn: TextView
    private lateinit var renderBtn: TextView
    private lateinit var speedBtn: TextView
    private lateinit var wmBtn: TextView
    private lateinit var segBox: LinearLayout
    private lateinit var bar: ProgressBar
    private lateinit var editStatus: TextView
    private lateinit var gifBtn: TextView
    private lateinit var gifBox: LinearLayout
    private lateinit var gifImg: ImageView
    private lateinit var gifStatus: TextView
    private lateinit var finalBox: LinearLayout
    private lateinit var finalVideo: VideoView
    private lateinit var finalPlayBtn: TextView
    private lateinit var pubBtn: TextView
    private lateinit var pubStatus: TextView
    private lateinit var urlText: TextView
    private lateinit var linkBox: LinearLayout
    private lateinit var posterImg: ImageView
    private lateinit var posterSeek: SeekBar
    private lateinit var waBtn: TextView
    private lateinit var waStatus: TextView
    private lateinit var waRow: LinearLayout

    // publication SFTP
    private val fieldViews = LinkedHashMap<String, EditText>()
    private lateinit var pubSettingsStatus: TextView
    private lateinit var serverRowValue: TextView

    /* ================= cycle de vie ================= */

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        Pal.apply(prefs.opt("theme", "dark") == "dark")
        window.setBackgroundDrawable(ColorDrawable(Pal.bg))
        window.statusBarColor = Pal.bg
        window.navigationBarColor = Pal.bg

        val shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Pal.bg) }
        content = FrameLayout(this)
        shell.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        shell.addView(View(this).apply { setBackgroundColor(Pal.line) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)))
        nav = buildNav()
        shell.addView(nav, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(66)))
        setContentView(shell)
        val light = if (Pal.dark) 0 else
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        window.insetsController?.setSystemBarsAppearance(
            light,
            WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
        )

        buildHome()
        buildPhotos()
        buildTools()
        buildSettings()
        buildEditor()
        buildPub()
        buildAbout()
        for (p in listOf<View>(pgHome, pgPhotos, pgTools, pgSettings, pgEditor, pgPub, pgAbout)) {
            content.addView(p, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        showTab(0)
        handleIntent(intent)
        ui.post(tick)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        val sub = pgEditor.visibility == View.VISIBLE || pgPub.visibility == View.VISIBLE || pgAbout.visibility == View.VISIBLE
        if (!sub) showTab(tab)
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        transformer?.cancel()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            pgEditor.visibility == View.VISIBLE -> leaveEditor()
            pgPub.visibility == View.VISIBLE -> showTab(3)
            pgAbout.visibility == View.VISIBLE -> showTab(tab)
            tab != 0 -> showTab(0)
            else -> super.onBackPressed()
        }
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val name = i.getStringExtra(RecorderService.EXTRA_OPEN)
        if (name != null) {
            i.removeExtra(RecorderService.EXTRA_OPEN)
            val d = File(Store.root(this), name)
            if (d.isDirectory && File(d, "original.mp4").exists()) openEditor(d)
        }
        if (i.getStringExtra("quick") == "record") {
            i.removeExtra("quick")
            ui.postDelayed({ startFlow(ACT_RECORD) }, 300)
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            if (pgEditor.visibility == View.VISIBLE && video.isPlaying) {
                val p = video.currentPosition.toLong()
                trim.position = p
                if (previewing && p >= trim.end) {
                    video.pause()
                    video.seekTo(trim.end.toInt())
                    previewing = false
                    playBtn.text = "Lecture"
                }
                trim.invalidate()
            }
            ui.postDelayed(this, 60)
        }
    }

    /* ================= utilitaires ================= */

    private fun dialog(): AlertDialog.Builder = AlertDialog.Builder(
        this,
        if (Pal.dark) android.R.style.Theme_Material_Dialog_Alert else android.R.style.Theme_Material_Light_Dialog_Alert
    )

    private fun videoFrame(v: VideoView, heightDp: Int): FrameLayout = FrameLayout(this).apply {
        setBackgroundColor(Pal.black)
        addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        minimumHeight = dp(heightDp)
    }

    private fun styledEdit(hintText: String, size: Float = 16f): EditText = EditText(this).apply {
        hint = hintText
        setHintTextColor(Pal.mut)
        setTextColor(Pal.fg)
        textSize = size
        typeface = font("sans-serif-medium")
        backgroundTintList = ColorStateList.valueOf(Pal.mut)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun status(t: TextView, msg: String, color: Int = Pal.mut) {
        t.text = msg
        t.setTextColor(color)
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun clock(ms: Long): String {
        val s = ms / 1000
        return String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60)
    }

    private fun emptyState(msg: String): View = column().apply {
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(0, dp(40), 0, dp(20))
        addView(icon(R.drawable.ic_videocam, Pal.line, 96))
        addView(label(msg, 14f, Pal.mut).apply { gravity = Gravity.CENTER; setPadding(dp(20), dp(14), dp(20), 0) })
    }

    private fun card(): LinearLayout = column().apply {
        background = roundBg(Pal.panel, 18, Pal.line, 1)
        setPadding(dp(16), dp(14), dp(16), dp(14))
    }

    /* ================= navigation ================= */

    private fun buildNav(): LinearLayout {
        val n = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Pal.bg)
            gravity = Gravity.CENTER_VERTICAL
        }
        fun item(idx: Int, res: Int, text: String) {
            val col = column().apply { gravity = Gravity.CENTER }
            val ic = icon(res, Pal.mut, 24)
            val tv = caption(text).apply { gravity = Gravity.CENTER; textSize = 9f; setPadding(0, dp(3), 0, 0) }
            col.addView(ic)
            col.addView(tv)
            navIcons.add(ic)
            navLabels.add(tv)
            col.setOnClickListener { showTab(idx) }
            n.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }
        item(0, R.drawable.ic_videocam, "Vidéo")
        item(1, R.drawable.ic_image, "Photo")
        val plus = FrameLayout(this).apply {
            background = ovalBg(Pal.acc)
            addView(icon(R.drawable.ic_add, Pal.onAcc, 26), FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
            setOnClickListener { showPlusMenu() }
        }
        val plusWrap = FrameLayout(this)
        plusWrap.addView(plus, FrameLayout.LayoutParams(dp(50), dp(50), Gravity.CENTER))
        n.addView(plusWrap, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        item(2, R.drawable.ic_edit, "Modifier")
        item(3, R.drawable.ic_settings, "Réglages")
        return n
    }

    private fun showTab(i: Int) {
        tab = i
        val pages = listOf<View>(pgHome, pgPhotos, pgTools, pgSettings)
        pages.forEachIndexed { k, p -> p.visibility = if (k == i) View.VISIBLE else View.GONE }
        pgEditor.visibility = View.GONE
        pgPub.visibility = View.GONE
        pgAbout.visibility = View.GONE
        nav.visibility = View.VISIBLE
        for (k in navIcons.indices) {
            val sel = k == i
            val c = if (sel) Pal.fg else Pal.mut
            navIcons[k].setColorFilter(c)
            navLabels[k].setTextColor(c)
        }
        when (i) {
            0 -> refreshHome()
            1 -> refreshPhotos()
            2 -> refreshTools()
        }
    }

    private fun showSub(v: View) {
        listOf<View>(pgHome, pgPhotos, pgTools, pgSettings, pgEditor, pgPub, pgAbout).forEach {
            it.visibility = if (it === v) View.VISIBLE else View.GONE
        }
        nav.visibility = View.GONE
    }

    private fun showPlusMenu() {
        val items = arrayOf("Enregistrer l'écran", "Capture d'écran", "Importer une vidéo de la galerie")
        dialog().setItems(items) { _, which ->
            when (which) {
                0 -> onRecordClicked()
                1 -> startFlow(ACT_SHOT)
                2 -> importVideo()
            }
        }.show()
    }

    /* ================= accueil ================= */

    private fun buildHome() {
        val c = column()

        // en-tête
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.hex_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            outlineProvider = rounded(12)
            clipToOutline = true
        }
        head.addView(logo, LinearLayout.LayoutParams(dp(46), dp(46)))
        val titles = column()
        titles.addView(heading("HEX-REC", 24f))
        val date = SimpleDateFormat("EEEE d MMMM", Locale.FRENCH).format(Date())
        titles.addView(caption(date))
        head.addView(titles, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(12) })
        c.add(head, 0)

        // statistiques
        statVideos = heading("0", 22f)
        statMinutes = heading("0", 22f)
        statPublished = heading("0", 22f)
        fun stat(v: TextView, name: String): LinearLayout = card().apply {
            setPadding(dp(14), dp(12), dp(14), dp(12))
            addView(v)
            addView(caption(name))
        }
        c.add(row(stat(statVideos, "Vidéos"), stat(statMinutes, "Minutes"), stat(statPublished, "Publiées")), 20)

        // raccourcis (interrupteurs)
        c.add(caption("Raccourcis"), 26)
        val sc = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val s1 = makeShortcut(R.drawable.ic_brush, "Brosse", { prefs.flag("brush", true) }) {
            val on = !prefs.flag("brush", true)
            prefs.setFlag("brush", on)
            if (on) {
                prefs.setFlag("ball", true)
                toast("Brosse : disponible dans le bouton flottant pendant l'enregistrement.")
            }
        }
        val s2 = makeShortcut(R.drawable.ic_person, "Caméra faciale", { prefs.flag("cam", true) }) {
            prefs.setFlag("cam", !prefs.flag("cam", true))
        }
        val s3 = makeShortcut(R.drawable.ic_photo_camera, "Capture", { false }) { startFlow(ACT_SHOT) }
        val s4 = makeShortcut(R.drawable.ic_videocam, "Bouton flottant", { prefs.flag("ball", true) }) {
            prefs.setFlag("ball", !prefs.flag("ball", true))
        }
        for (s in listOf(s1, s2, s3, s4)) sc.addView(s, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        c.add(sc, 12)

        // profils
        c.add(caption("Profils d'enregistrement"), 26)
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for ((key, name) in listOf("tuto" to "Tuto", "jeu" to "Jeu", "presentation" to "Présentation", "leger" to "Léger")) {
            val chip = TextView(this).apply {
                text = name
                textSize = 13f
                typeface = font("sans-serif-medium")
                setPadding(dp(16), dp(9), dp(16), dp(9))
                setOnClickListener { applyPreset(key) }
            }
            presetViews.add(key to chip)
            chips.addView(chip, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { rightMargin = dp(8) })
        }
        c.add(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) }, 12)

        // plus d'outils
        c.add(caption("Plus d'outils"), 26)
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val t1 = makeShortcut(R.drawable.ic_image, "Importer", { false }) { importVideo() }
        val t2 = makeShortcut(R.drawable.ic_movie, "GIF", { false }) {
            toast("Ouvre un enregistrement, puis « Exporter en GIF ».")
            showTab(2)
        }
        val t3 = makeShortcut(R.drawable.ic_share, "WhatsApp", { false }) {
            toast("Fais le rendu, puis « Compresser pour WhatsApp ».")
            showTab(2)
        }
        val t4 = makeShortcut(R.drawable.ic_group, "CENTRAL-HEX", { false }) { showSub(pgAbout) }
        for (s in listOf(t1, t2, t3, t4)) tools.addView(s, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        c.add(tools, 12)

        homeDyn = column()
        c.add(homeDyn, 4)

        pgHome = FrameLayout(this)
        pgHome.addView(pageScroll(c, 130), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = roundBg(Pal.acc, 32)
            elevation = dp(6).toFloat()
            setOnClickListener { onRecordClicked() }
        }
        pill.addView(View(this).apply { background = ovalBg(Pal.rec) }, LinearLayout.LayoutParams(dp(14), dp(14)))
        pillText = TextView(this).apply {
            text = "ENREGISTRER"
            textSize = 16f
            setTextColor(Pal.onAcc)
            typeface = font("sans-serif-black")
            letterSpacing = 0.12f
            setPadding(dp(12), 0, 0, 0)
        }
        pill.addView(pillText)
        pgHome.addView(pill, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58), Gravity.BOTTOM).apply {
            setMargins(dp(22), 0, dp(22), dp(16))
        })
    }

    private fun makeShortcut(res: Int, text: String, active: () -> Boolean, onTap: () -> Unit): LinearLayout {
        val circle = FrameLayout(this)
        val ic = icon(res, Pal.fg, 26)
        circle.addView(ic, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        val col = column().apply { gravity = Gravity.CENTER_HORIZONTAL }
        col.addView(circle, LinearLayout.LayoutParams(dp(62), dp(62)))
        col.addView(label(text, 12f, Pal.fg).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) })
        col.setOnClickListener { onTap(); refreshShortcuts() }
        shortcuts.add(Shortcut(circle, ic, active))
        return col
    }

    private fun refreshShortcuts() {
        for (s in shortcuts) {
            val on = s.active()
            s.circle.background = if (on) ovalBg(Pal.acc) else ovalBg(Pal.panel, Pal.line, 1)
            s.icon.setColorFilter(if (on) Pal.onAcc else Pal.fg)
        }
    }

    private fun refreshPresets() {
        val cur = prefs.opt("preset", "tuto")
        for ((k, v) in presetViews) {
            val on = k == cur
            v.background = if (on) roundBg(Pal.acc, 22) else roundBg(Pal.panel, 22, Pal.line, 1)
            v.setTextColor(if (on) Pal.onAcc else Pal.fg)
        }
    }

    private fun applyPreset(key: String) {
        // res, fps, qualité, décompte, webcam, micro
        val v = when (key) {
            "jeu" -> listOf("1080", "60", "high", "3", "0", "1")
            "presentation" -> listOf("1080", "30", "high", "5", "1", "1")
            "leger" -> listOf("720", "30", "std", "0", "0", "1")
            else -> listOf("1080", "30", "std", "3", "1", "1")
        }
        prefs.put("res", v[0]); prefs.put("fps", v[1]); prefs.put("quality", v[2])
        prefs.put("countdown", v[3]); prefs.put("cam", v[4]); prefs.put("mic", v[5])
        prefs.put("preset", key)
        refreshPresets()
        refreshShortcuts()
        val name = mapOf("tuto" to "Tuto", "jeu" to "Jeu", "presentation" to "Présentation", "leger" to "Léger")[key]
        toast("Profil ${name} : ${v[0]}p · ${v[1]} i/s")
    }

    private fun storageInfo(): Pair<String, Int> = try {
        val st = StatFs(Environment.getDataDirectory().path)
        val total = st.blockCountLong * st.blockSizeLong
        val free = st.availableBlocksLong * st.blockSizeLong
        Pair(
            String.format(Locale.US, "%.1f / %.1f Go", (total - free) / 1e9, total / 1e9),
            if (total > 0) (((total - free) * 100) / total).toInt() else 0
        )
    } catch (e: Exception) { Pair("", 0) }

    private fun refreshHome() {
        refreshShortcuts()
        refreshPresets()
        pillText.text = if (RecorderService.running) "ARRÊTER" else "ENREGISTRER"
        val list = Store.list(this)
        statVideos.text = list.size.toString()
        var totalMs = 0L
        var pubCount = 0
        for (d in list) {
            totalMs += Store.readMeta(d).optLong("durationMs", 0L)
            if (File(d, "publish.json").exists()) pubCount++
        }
        statMinutes.text = (totalMs / 60000L).toString()
        statPublished.text = pubCount.toString()

        homeDyn.removeAllViews()

        // vidéos
        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        titleRow.addView(heading("Vidéo", 22f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val (sText, sPct) = storageInfo()
        val chip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = roundBg(Pal.bg, 20, Pal.line, 1)
            setPadding(dp(10), dp(7), dp(10), dp(7))
        }
        chip.addView(icon(R.drawable.ic_phone, Pal.fg, 18))
        chip.addView(label(sText, 12f, Pal.mut).apply { setPadding(dp(8), 0, dp(4), 0) })
        titleRow.addView(chip)
        homeDyn.add(titleRow, 28)
        val storageBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = sPct
            progressTintList = ColorStateList.valueOf(Pal.fg)
            progressBackgroundTintList = ColorStateList.valueOf(Pal.line)
        }
        homeDyn.add(storageBar, 8, dp(6))

        if (list.isEmpty()) homeDyn.add(emptyState("Aucune vidéo pour l'instant.\nTouche « Enregistrer » pour commencer."), 4)
        for (d in list.take(5)) homeDyn.add(recordingRow(d), 0)
        if (list.size > 5) homeDyn.add(button("Voir les ${list.size} enregistrements") { showTab(2) }, 10)

        // captures
        val shots = Store.listShots(this)
        if (shots.isNotEmpty()) {
            homeDyn.add(caption("Captures d'écran"), 28)
            val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (f in shots.take(8)) {
                val iv = ImageView(this).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    background = roundBg(Pal.panel, 12)
                    outlineProvider = rounded(12)
                    clipToOutline = true
                    setOnClickListener { showTab(1) }
                }
                Thread { val b = decode(f, 300); if (b != null) ui.post { iv.setImageBitmap(b) } }.start()
                strip.addView(iv, LinearLayout.LayoutParams(dp(84), dp(120)).apply { rightMargin = dp(8) })
            }
            homeDyn.add(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(strip) }, 10)
        }

        // dernier lien publié
        val lastPub = list.firstOrNull { File(it, "publish.json").exists() }
        if (lastPub != null) {
            val url = try { JSONObject(File(lastPub, "publish.json").readText()).getString("url") } catch (e: Exception) { "" }
            if (url.isNotEmpty()) {
                homeDyn.add(caption("Dernier lien publié"), 28)
                val cd = card()
                cd.addView(label(Store.readMeta(lastPub).optString("title", lastPub.name), 15f, bold = true))
                cd.addView(label(url, 13f, Pal.mut).apply { setPadding(0, dp(4), 0, dp(10)) })
                cd.addView(row(button("Copier") { copyText(url) }, button("Partager") { shareText(url) }))
                homeDyn.add(cd, 10)
            }
        }

        // astuce du jour
        val tip = TIPS[Calendar.getInstance().get(Calendar.DAY_OF_YEAR) % TIPS.size]
        homeDyn.add(caption("Astuce"), 28)
        val tipCard = card()
        tipCard.addView(label(tip, 14f))
        homeDyn.add(tipCard, 10)

        // communauté
        homeDyn.add(caption("Communauté"), 28)
        val com = card()
        val comHead = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val cl = ImageView(this).apply { setImageResource(R.drawable.hex_logo); outlineProvider = rounded(10); clipToOutline = true }
        comHead.addView(cl, LinearLayout.LayoutParams(dp(44), dp(44)))
        val ct = column()
        ct.addView(heading("CENTRAL-HEX", 16f))
        ct.addView(label("Tech, IA, bots et projets digitaux.", 13f, Pal.mut))
        comHead.addView(ct, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(12) })
        com.addView(comHead)
        com.addView(row(button("Rejoindre la chaîne", true) { openUrl(CH_LINK) }, button("En savoir plus") { showSub(pgAbout) }),
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(14) })
        homeDyn.add(com, 10)
    }

    private fun recordingRow(d: File): View {
        val meta = Store.readMeta(d)
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val thumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = roundBg(Pal.panel, 10)
            outlineProvider = rounded(10)
            clipToOutline = true
        }
        r.addView(thumb, LinearLayout.LayoutParams(dp(104), dp(66)))
        loadThumb(d, thumb)
        val info = column()
        info.addView(label(meta.optString("title", d.name), 15f, bold = true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        })
        val tag = when {
            File(d, "publish.json").exists() -> "  ·  PUBLIÉ"
            File(d, "final.mp4").exists() -> "  ·  RENDU"
            else -> ""
        }
        info.addView(label(d.name.take(10) + "  ·  " + clock(meta.optLong("durationMs", 0L)) + tag, 12f, Pal.mut).apply { setPadding(0, dp(4), 0, 0) })
        r.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(12) })
        r.setOnClickListener { openEditor(d) }
        r.setOnLongClickListener { confirmDelete(d); true }
        return r
    }

    private fun loadThumb(d: File, iv: ImageView) {
        Thread {
            val cache = File(d, "thumb.jpg")
            var bmp: Bitmap? = if (cache.exists()) BitmapFactory.decodeFile(cache.path) else null
            if (bmp == null) {
                val mr = MediaMetadataRetriever()
                try {
                    mr.setDataSource(File(d, "original.mp4").path)
                    val f = mr.getFrameAtTime(500_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: mr.getFrameAtTime(0)
                    if (f != null) {
                        val w = 320
                        val h = (f.height * w / f.width.toFloat()).toInt().coerceAtLeast(1)
                        val scaled = Bitmap.createScaledBitmap(f, w, h, true)
                        FileOutputStream(cache).use { scaled.compress(Bitmap.CompressFormat.JPEG, 80, it) }
                        bmp = scaled
                    }
                } catch (e: Exception) {
                } finally {
                    mr.release()
                }
            }
            val b = bmp
            if (b != null) ui.post { iv.setImageBitmap(b) }
        }.start()
    }

    private fun confirmDelete(d: File) {
        dialog()
            .setTitle("Supprimer cet enregistrement ?")
            .setMessage("Les fichiers du téléphone seront effacés. La page déjà publiée reste en ligne.")
            .setPositiveButton("Supprimer") { _, _ -> d.deleteRecursively(); showTab(tab) }
            .setNegativeButton("Annuler", null)
            .show()
    }

    /* ================= enregistrement / capture ================= */

    private fun onRecordClicked() {
        if (RecorderService.running) {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
            return
        }
        startFlow(ACT_RECORD)
    }

    private fun startFlow(action: Int) {
        if (RecorderService.running) { toast("Un enregistrement est déjà en cours."); return }
        pendingAction = action
        val need = mutableListOf<String>()
        if (action == ACT_RECORD) {
            val cam = prefs.flag("cam", true)
            val mic = prefs.flag("mic", true)
            val ball = prefs.flag("ball", true)
            if ((cam || ball) && !Settings.canDrawOverlays(this)) {
                toast("Autorise « Affichage par-dessus les autres applis » (bulle webcam et bouton flottant), puis reviens.")
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return
            }
            if (cam && !granted(Manifest.permission.CAMERA)) need += Manifest.permission.CAMERA
            if (mic && !granted(Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
        }
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), REQ_PERMS)
            return
        }
        askProjection()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERMS) askProjection()   // le service désactive ce qui a été refusé
    }

    @Suppress("DEPRECATION")
    private fun askProjection() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJ)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_PROJ -> {
                if (resultCode != RESULT_OK || data == null) {
                    toast("Capture d'écran refusée.")
                    return
                }
                val i = Intent(this, RecorderService::class.java)
                    .setAction(if (pendingAction == ACT_SHOT) RecorderService.ACTION_SHOT else RecorderService.ACTION_START)
                    .putExtra(RecorderService.EXTRA_CODE, resultCode)
                    .putExtra(RecorderService.EXTRA_DATA, data)
                    .putExtra(RecorderService.EXTRA_CAM, prefs.flag("cam", true))
                    .putExtra(RecorderService.EXTRA_MIC, prefs.flag("mic", true))
                ContextCompat.startForegroundService(this, i)
                if (pendingAction == ACT_RECORD && prefs.flag("ball", true)) {
                    toast("Bouton flottant actif : touche-le pour pause, arrêt et brosse.")
                }
                ui.postDelayed({ moveTaskToBack(true) }, 600)
            }
            REQ_IMPORT -> {
                val uri = data?.data
                if (resultCode == RESULT_OK && uri != null) {
                    toast("Import en cours…")
                    Thread {
                        try {
                            val d = Store.importVideo(this, uri, "Vidéo importée")
                            ui.post { openEditor(d) }
                        } catch (e: Exception) {
                            ui.post { toast("Import impossible : ${e.message}") }
                        }
                    }.start()
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun importVideo() {
        val i = Intent(Intent.ACTION_GET_CONTENT).setType("video/*").addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(Intent.createChooser(i, "Choisir une vidéo"), REQ_IMPORT)
    }

    /* ================= onglet Photo ================= */

    private fun buildPhotos() {
        val c = column()
        c.add(heading("Photo", 24f), 0)
        photosBox = column()
        c.add(photosBox, 14)
        pgPhotos = pageScroll(c)
    }

    private fun refreshPhotos() {
        photosBox.removeAllViews()
        val shots = Store.listShots(this)
        if (shots.isEmpty()) {
            photosBox.addView(emptyState("Aucune capture d'écran.\nTouche « Capture » sur l'accueil."))
            return
        }
        for (pair in shots.chunked(2)) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for ((k, f) in pair.withIndex()) {
                r.addView(photoCell(f), LinearLayout.LayoutParams(0, dp(210), 1f).apply { if (k > 0) leftMargin = dp(8) })
            }
            if (pair.size == 1) r.addView(View(this), LinearLayout.LayoutParams(0, dp(210), 1f).apply { leftMargin = dp(8) })
            photosBox.add(r, 8)
        }
    }

    private fun decode(f: File, maxW: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / s > maxW) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    private fun photoCell(f: File): ImageView {
        val iv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = roundBg(Pal.panel, 12)
            outlineProvider = rounded(12)
            clipToOutline = true
        }
        Thread { val b = decode(f, 600); if (b != null) ui.post { iv.setImageBitmap(b) } }.start()
        iv.setOnClickListener { viewPhoto(f) }
        iv.setOnLongClickListener {
            dialog().setTitle("Supprimer cette capture ?")
                .setPositiveButton("Supprimer") { _, _ -> f.delete(); refreshPhotos() }
                .setNegativeButton("Annuler", null).show()
            true
        }
        return iv
    }

    private fun viewPhoto(f: File) {
        val dlg = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val box = FrameLayout(this).apply { setBackgroundColor(Pal.black) }
        val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        Thread { val b = decode(f, 1600); if (b != null) ui.post { iv.setImageBitmap(b) } }.start()
        box.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btns.addView(button("Partager", true) { shareFile(f, "image/png") }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        btns.addView(button("Fermer") { dlg.dismiss() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(10) })
        box.addView(btns, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
            setMargins(dp(18), 0, dp(18), dp(24))
        })
        dlg.setContentView(box)
        dlg.show()
    }

    /* ================= onglet Modifier ================= */

    private fun buildTools() {
        val c = column()
        c.add(heading("Modifier", 24f), 0)
        c.add(label("Découpe, accélère, exporte en MP4, GIF ou version WhatsApp, puis publie.", 14f, Pal.mut), 6)
        c.add(button("Importer une vidéo de la galerie", true) { importVideo() }, 18)
        c.add(caption("Mes enregistrements"), 26)
        toolsList = column()
        c.add(toolsList, 6)
        pgTools = pageScroll(c)
    }

    private fun refreshTools() {
        toolsList.removeAllViews()
        val list = Store.list(this)
        if (list.isEmpty()) toolsList.addView(emptyState("Aucun enregistrement à modifier."))
        for (d in list.take(40)) toolsList.addView(recordingRow(d))
    }

    /* ================= onglet Réglages ================= */

    private fun settingRow(title: String, value: TextView, onTap: () -> Unit): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, dp(14))
            setOnClickListener { onTap() }
        }
        r.addView(label(title, 15f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(value)
        r.addView(icon(R.drawable.ic_chevron_right, Pal.mut, 20))
        val wrap = column()
        wrap.addView(r)
        wrap.addView(View(this).apply { setBackgroundColor(Pal.line) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)))
        return wrap
    }

    private fun valueLabel(): TextView = label("", 13f, Pal.mut, true).apply { setPadding(0, 0, dp(4), 0) }

    private fun cycleRow(c: LinearLayout, title: String, key: String, def: String, opts: List<Pair<String, String>>, onChange: (() -> Unit)? = null) {
        val value = valueLabel()
        fun refresh() {
            val cur = prefs.opt(key, def)
            value.text = opts.firstOrNull { it.first == cur }?.second ?: opts[0].second
        }
        c.add(settingRow(title, value) {
            val cur = opts.indexOfFirst { it.first == prefs.opt(key, def) }
            prefs.put(key, opts[(cur + 1) % opts.size].first)
            refresh()
            onChange?.invoke()
        }, 0)
        refresh()
    }

    private fun buildSettings() {
        val c = column()
        c.add(heading("Réglages", 24f), 0)
        val onOff = listOf("1" to "Activé", "0" to "Désactivé")

        c.add(caption("Enregistrement"), 24)
        cycleRow(c, "Résolution", "res", "1080", listOf("1080" to "1080p", "720" to "720p", "480" to "480p"))
        cycleRow(c, "Images par seconde", "fps", "30", listOf("30" to "30 i/s", "60" to "60 i/s"))
        cycleRow(c, "Qualité vidéo", "quality", "std", listOf("std" to "Standard", "high" to "Élevée"))
        cycleRow(c, "Décompte", "countdown", "3", listOf("0" to "Aucun", "3" to "3 s", "5" to "5 s", "10" to "10 s"))
        cycleRow(c, "Micro", "mic", "1", onOff)
        cycleRow(c, "Limite de durée", "limit", "0", listOf("0" to "Aucune", "5" to "5 min", "10" to "10 min", "30" to "30 min", "60" to "1 h"))
        cycleRow(c, "Secouer pour arrêter", "shake", "0", onOff.reversed())

        c.add(caption("Webcam"), 26)
        cycleRow(c, "Bulle webcam", "cam", "1", onOff)
        cycleRow(c, "Taille de la bulle", "bubble", "M", listOf("S" to "Petite", "M" to "Moyenne", "L" to "Grande"))
        cycleRow(c, "Caméra de la bulle", "camera", "front", listOf("front" to "Avant", "back" to "Arrière"))

        c.add(caption("Outils"), 26)
        cycleRow(c, "Bouton flottant (pause, arrêt)", "ball", "1", onOff)
        cycleRow(c, "Brosse (dessin à l'écran)", "brush", "1", onOff)

        c.add(caption("Montage"), 26)
        cycleRow(c, "Résolution du rendu", "render", "1080", listOf("1080" to "1080p", "720" to "720p"))
        cycleRow(c, "Filigrane HEX-REC", "watermark", "1", onOff)

        c.add(caption("Apparence"), 26)
        cycleRow(c, "Thème", "theme", "dark", listOf("dark" to "Noir", "light" to "Blanc")) { recreate() }

        c.add(caption("Publication"), 26)
        serverRowValue = valueLabel()
        c.add(settingRow("Serveur de partage", serverRowValue) { showSub(pgPub) }, 0)
        serverRowValue.text = if (prefs.configured()) "Configuré" else "À configurer"

        c.add(caption("Communauté"), 26)
        val joinValue = valueLabel().apply { text = "Rejoindre" }
        c.add(settingRow("CENTRAL-HEX", joinValue) { showSub(pgAbout) }, 0)

        c.add(caption("Réglages rapides"), 26)
        c.add(label("Ajoute la tuile HEX-REC : glisse le panneau de notifications vers le bas, touche le crayon (modifier), puis fais glisser « HEX-REC » dans tes tuiles. Un toucher démarre ou arrête l'enregistrement.", 13f, Pal.mut), 8)

        c.add(caption("À propos"), 26)
        c.add(label("HEX-REC 1.3 · Enregistreur d'écran, montage et partage. Sans compte ni télémétrie.", 13f, Pal.mut), 8)
        pgSettings = pageScroll(c)
    }

    /* ================= serveur de partage (SFTP) ================= */

    private fun buildPub() {
        val c = column()
        c.add(row(button("← Retour") { saveFields(); showTab(3) }), 0)
        c.add(heading("Serveur de partage", 20f), 16)
        c.add(label("La vidéo est envoyée sur ton VPS par SFTP. Rien d'autre ne sort du téléphone.", 13f, Pal.mut), 6)

        data class F(val key: String, val title: String, val hint: String, val kind: Int, val multi: Boolean = false)
        val uri = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        val pass = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        val fields = listOf(
            F("author", "Ton nom (affiché sur la page)", "Ton Nom", InputType.TYPE_CLASS_TEXT),
            F("baseUrl", "URL de partage", "https://share.example.com", uri),
            F("host", "Serveur SSH", "ton-vps.example.com", uri),
            F("port", "Port", "22", InputType.TYPE_CLASS_NUMBER),
            F("user", "Utilisateur SSH", "share", uri),
            F("dataDir", "Dossier distant", "/srv/share/data", uri),
            F("password", "Mot de passe SSH (si pas de clé)", "", pass),
            F("key", "Clé privée (optionnel, RSA/ECDSA recommandé)", "-----BEGIN OPENSSH PRIVATE KEY-----",
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE, true),
            F("passphrase", "Mot de passe de la clé (si chiffrée)", "", pass)
        )
        for (f in fields) {
            c.add(caption(f.title), 18)
            val e = styledEdit(f.hint, 15f).apply {
                inputType = f.kind
                setText(prefs.get(f.key))
                if (f.multi) {
                    minLines = 4
                    maxLines = 8
                    gravity = Gravity.TOP or Gravity.START
                    textSize = 12f
                } else {
                    isSingleLine = true
                }
            }
            fieldViews[f.key] = e
            c.add(e, 2)
        }
        pubSettingsStatus = label("", 14f, Pal.mut)
        c.add(button("Enregistrer", true) {
            saveFields()
            status(pubSettingsStatus, "Réglages enregistrés.", Pal.ok)
        }, 22)
        c.add(button("Tester la connexion") { testConnection() }, 8)
        c.add(button("Oublier la clé du serveur") {
            prefs.put("known_hosts", "")
            status(pubSettingsStatus, "Clé du serveur oubliée.")
        }, 8)
        c.add(pubSettingsStatus, 10)
        pgPub = pageScroll(c)
    }

    private fun saveFields() {
        for ((k, e) in fieldViews) {
            val raw = e.text.toString()
            prefs.put(k, if (k == "password" || k == "passphrase") raw else raw.trim())
        }
        serverRowValue.text = if (prefs.configured()) "Configuré" else "À configurer"
    }

    private fun testConnection() {
        saveFields()
        status(pubSettingsStatus, "Connexion…")
        Thread {
            val msg = try { Publisher.test(prefs) to Pal.ok } catch (e: Exception) { ("Échec : ${e.message}") to Pal.err }
            ui.post { status(pubSettingsStatus, msg.first, msg.second) }
        }.start()
    }

    /* ================= page CENTRAL-HEX ================= */

    private fun bullet(c: LinearLayout, title: String, text: String) {
        c.add(label(title, 15f, bold = true), 14)
        c.add(label(text, 14f, Pal.mut), 2)
    }

    private fun infoLine(c: LinearLayout, name: String, value: String, onTap: (() -> Unit)? = null) {
        c.add(caption(name), 16)
        val v = label(value, 16f, if (onTap != null) Pal.fg else Pal.fg, true)
        if (onTap != null) {
            v.paintFlags = v.paintFlags or Paint.UNDERLINE_TEXT_FLAG
            v.setOnClickListener { onTap() }
        }
        c.add(v, 3)
    }

    private fun buildAbout() {
        val c = column()
        c.add(row(button("← Retour") { showTab(tab) }), 0)

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.hex_logo)
            outlineProvider = rounded(14)
            clipToOutline = true
        }
        head.addView(logo, LinearLayout.LayoutParams(dp(60), dp(60)))
        val t = column()
        t.addView(heading("CENTRAL-HEX", 22f))
        t.addView(caption("La communauté Tech & Digital"))
        head.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(14) })
        c.add(head, 18)

        c.add(label("La plateforme ultime pour les passionnés de technologie et de digital.", 16f), 18)

        c.add(caption("Ce que tu y trouves"), 26)
        bullet(c, "Explorer la tech et l'IA", "Bots, automatisation, intelligence artificielle.")
        bullet(c, "Créer ton univers digital", "Sites web, outils, projets en ligne.")
        bullet(c, "Développer et automatiser tes idées", "Bots WhatsApp, scripts, solutions pratiques.")
        bullet(c, "Accéder à des ressources exclusives", "Guides, tutoriels, astuces avancées.")
        bullet(c, "Innover et partager", "Idées business, projets collaboratifs, challenges créatifs.")

        c.add(caption("Notre mission"), 28)
        c.add(label("Construire une communauté forte, active et innovante, où l'apprentissage se transforme en action. Ici, on ne reste pas spectateur : on apprend, on applique, on évolue.", 14f, Pal.mut), 8)

        c.add(caption("Contact"), 28)
        infoLine(c, "Créateur", "Ibrahima Sory Sacko")
        infoLine(c, "Pseudo", "SALGADO")
        infoLine(c, "Adresse e-mail", EMAIL) { sendMail() }
        infoLine(c, "Chaîne WhatsApp", CH_LINK) { openUrl(CH_LINK) }

        c.add(button("Rejoindre la chaîne WhatsApp", true) { openUrl(CH_LINK) }, 24)
        c.add(row(button("Écrire un e-mail") { sendMail() }, button("Copier l'e-mail") { copyText(EMAIL) }), 8)
        c.add(button("Partager la chaîne") { shareText("Rejoins CENTRAL-HEX, la communauté Tech & Digital : $CH_LINK") }, 8)
        c.add(caption("Où la technologie rencontre la créativité").apply { gravity = Gravity.CENTER }, 30)
        pgAbout = pageScroll(c)
    }

    /* ================= partage / liens ================= */

    private fun shareFile(f: File, mime: String) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val i = Intent(Intent.ACTION_SEND).setType(mime)
                .putExtra(Intent.EXTRA_STREAM, uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Partager"))
        } catch (e: Exception) {
            toast("Partage impossible : ${e.message}")
        }
    }

    private fun shareText(text: String) {
        try {
            val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
            startActivity(Intent.createChooser(i, "Partager"))
        } catch (e: Exception) {
            toast("Partage impossible : ${e.message}")
        }
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) { toast("Impossible d'ouvrir le lien.") }
    }

    private fun copyText(text: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("texte", text))
        toast("Copié")
    }

    private fun sendMail() {
        try {
            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$EMAIL")))
        } catch (e: Exception) {
            copyText(EMAIL)
        }
    }

    private fun saveToGallery(f: File, name: String, mime: String, isVideo: Boolean, folder: String) {
        try {
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
            }
            val coll = if (isVideo) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val uri = contentResolver.insert(coll, v) ?: throw IllegalStateException("MediaStore indisponible")
            contentResolver.openOutputStream(uri)?.use { out -> FileInputStream(f).use { it.copyTo(out) } }
            toast("Enregistré dans la galerie")
        } catch (e: Exception) {
            toast("Export impossible : ${e.message}")
        }
    }

    /* ================= montage ================= */

    private fun buildEditor() {
        val c = column()
        c.add(row(button("← Retour") { leaveEditor() }), 0)
        titleEdit = styledEdit("Titre de la vidéo", 20f)
        c.add(titleEdit, 12)

        video = VideoView(this)
        c.add(videoFrame(video, 360), 10, dp(360))

        c.add(caption("Découpe"), 22)
        trim = TrimBar(this)
        trim.applyColors(Pal.line, Pal.fg, Pal.fg)
        trim.onDrag = { which ->
            val t = when (which) { 1 -> trim.start; 2 -> trim.end; else -> trim.position }
            video.pause()
            previewing = false
            playBtn.text = "Lecture"
            video.seekTo(t.toInt())
            updateTimes()
        }
        c.add(trim, 4)
        times = label("", 13f, Pal.mut)
        c.add(times, 0)

        playBtn = button("Lecture") { togglePlay() }
        val prev = button("Prévisualiser") {
            previewing = true
            video.seekTo(trim.start.toInt())
            video.start()
            playBtn.text = "Pause"
        }
        val setIn = button("Entrée ici") {
            trim.start = minOf(video.currentPosition.toLong(), trim.end - 200).coerceAtLeast(0L)
            trim.invalidate(); updateTimes()
        }
        val setOut = button("Sortie ici") {
            trim.end = maxOf(video.currentPosition.toLong(), trim.start + 200).coerceAtMost(dur)
            trim.invalidate(); updateTimes()
        }
        c.add(row(playBtn, prev), 10)
        c.add(row(setIn, setOut), 8)

        c.add(caption("Plusieurs coupes"), 26)
        c.add(label("Ajoute chaque passage à garder : le rendu les assemble dans l'ordre.", 13f, Pal.mut), 4)
        segBox = column()
        c.add(segBox, 6)
        c.add(row(
            button("+ Ajouter ce passage") { addSegment() },
            button("Vider la liste") { segments.clear(); refreshSegments() }
        ), 8)

        c.add(caption("Rendu"), 26)
        speedBtn = button("Vitesse : 1×") { cycleSpeed() }
        wmBtn = button("Filigrane") { toggleWatermark() }
        c.add(row(speedBtn, wmBtn), 8)
        renderBtn = button("Rendre en MP4 1080p", true) { render() }
        c.add(renderBtn, 12)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
            progressTintList = ColorStateList.valueOf(Pal.fg)
            progressBackgroundTintList = ColorStateList.valueOf(Pal.line)
        }
        c.add(bar, 12, dp(6))
        editStatus = label("", 14f, Pal.mut)
        c.add(editStatus, 8)

        gifBtn = button("Exporter en GIF") { exportGif() }
        c.add(gifBtn, 12)
        gifBox = column()
        gifImg = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; background = roundBg(Pal.panel, 12) }
        gifBox.add(gifImg, 0, dp(240))
        gifStatus = label("", 13f, Pal.mut)
        gifBox.add(gifStatus, 8)
        gifBox.add(row(
            button("Partager le GIF") { dir?.let { shareFile(File(it, "export.gif"), "image/gif") } },
            button("Dans la galerie") { dir?.let { saveToGallery(File(it, "export.gif"), it.name + ".gif", "image/gif", false, "Pictures/HEX-REC") } }
        ), 8)
        c.add(gifBox, 10)
        gifBox.visibility = View.GONE

        finalBox = column()
        finalBox.add(heading("Rendu final", 18f), 0)
        finalVideo = VideoView(this)
        finalBox.add(videoFrame(finalVideo, 300), 12, dp(300))
        finalPlayBtn = button("Lecture") {
            if (finalVideo.isPlaying) { finalVideo.pause(); finalPlayBtn.text = "Lecture" }
            else { finalVideo.start(); finalPlayBtn.text = "Pause" }
        }
        finalVideo.setOnCompletionListener { finalPlayBtn.text = "Lecture" }
        pubBtn = button("Publier", true) { publish() }
        finalBox.add(row(finalPlayBtn, pubBtn), 10)
        pubStatus = label("", 14f, Pal.mut)
        finalBox.add(pubStatus, 10)
        urlText = label("", 15f, Pal.fg, true).apply {
            paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG
            setOnClickListener { publishedUrl?.let { openUrl(it) } }
        }
        finalBox.add(urlText, 6)
        linkBox = row(
            button("Copier le lien") { publishedUrl?.let { copyText(it) } },
            button("Partager le lien") { publishedUrl?.let { shareText(it) } }
        )
        finalBox.add(linkBox, 8)
        finalBox.add(row(
            button("Partager la vidéo") { dir?.let { shareFile(File(it, "final.mp4"), "video/mp4") } },
            button("Dans la galerie") { dir?.let { saveToGallery(File(it, "final.mp4"), it.name + ".mp4", "video/mp4", true, "Movies/HEX-REC") } }
        ), 10)

        finalBox.add(caption("Image d'affiche"), 28)
        finalBox.add(label("Fais glisser pour choisir l'image du lien partagé.", 13f, Pal.mut), 4)
        posterImg = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Pal.black) }
        finalBox.add(posterImg, 10, dp(180))
        posterSeek = SeekBar(this).apply {
            progressTintList = ColorStateList.valueOf(Pal.fg)
            thumbTintList = ColorStateList.valueOf(Pal.fg)
            progressBackgroundTintList = ColorStateList.valueOf(Pal.line)
        }
        posterSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {}
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                loadPosterAt((seekBar?.progress ?: 0).toLong())
            }
        })
        finalBox.add(posterSeek, 8)
        finalBox.add(button("Utiliser cette image") { usePoster() }, 8)

        finalBox.add(caption("WhatsApp"), 28)
        finalBox.add(label("Version légère (moins de 16 Mo) pour l'envoyer par WhatsApp.", 13f, Pal.mut), 4)
        waBtn = button("Compresser pour WhatsApp") { compressWhatsApp() }
        finalBox.add(waBtn, 10)
        waStatus = label("", 13f, Pal.mut)
        finalBox.add(waStatus, 8)
        waRow = row(
            button("Partager") { dir?.let { shareFile(File(it, "whatsapp.mp4"), "video/mp4") } },
            button("Dans la galerie") { dir?.let { saveToGallery(File(it, "whatsapp.mp4"), it.name + "-wa.mp4", "video/mp4", true, "Movies/HEX-REC") } }
        )
        finalBox.add(waRow, 8)
        waRow.visibility = View.GONE

        c.add(finalBox, 30)
        finalBox.visibility = View.GONE
        pgEditor = pageScroll(c)
    }

    private fun fmtSpeed(): String = if (speed == speed.toInt().toFloat()) speed.toInt().toString() else speed.toString()

    private fun updateRenderLabels() {
        renderBtn.text = "Rendre en MP4 ${prefs.opt("render", "1080")}p"
        speedBtn.text = "Vitesse : ${fmtSpeed()}×"
        wmBtn.text = "Filigrane : " + if (prefs.flag("watermark", true)) "oui" else "non"
    }

    private fun cycleSpeed() {
        val opts = floatArrayOf(0.5f, 0.75f, 1f, 1.5f, 2f, 3f)
        val i = opts.indexOfFirst { it == speed }
        speed = opts[(i + 1) % opts.size]
        updateRenderLabels()
    }

    private fun toggleWatermark() {
        prefs.setFlag("watermark", !prefs.flag("watermark", true))
        updateRenderLabels()
    }

    private fun updateTimes() {
        times.text = "Entrée ${Store.fmt(trim.start)}    Durée ${Store.fmt(trim.end - trim.start)}    Sortie ${Store.fmt(trim.end)}"
    }

    private fun togglePlay() {
        if (video.isPlaying) {
            video.pause(); previewing = false; playBtn.text = "Lecture"
        } else {
            video.start(); playBtn.text = "Pause"
        }
    }

    /* ---- passages (plusieurs coupes) ---- */

    private fun currentSegments(): List<LongArray> =
        if (segments.isEmpty()) listOf(longArrayOf(trim.start, trim.end)) else segments.toList()

    private fun addSegment() {
        if (trim.end - trim.start < 300L) { toast("Passage trop court."); return }
        segments.add(longArrayOf(trim.start, trim.end))
        if (trim.end < dur - 500L) {
            trim.start = trim.end
            trim.end = dur
        } else {
            trim.start = 0L
            trim.end = dur
        }
        trim.invalidate()
        updateTimes()
        refreshSegments()
    }

    private fun refreshSegments() {
        segBox.removeAllViews()
        segments.forEachIndexed { i, s ->
            val r = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }
            r.addView(label("${i + 1}  ·  ${Store.fmt(s[0])} → ${Store.fmt(s[1])}", 14f, Pal.fg, true),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            r.addView(icon(R.drawable.ic_close, Pal.mut, 22).apply {
                setOnClickListener { segments.removeAt(i); refreshSegments() }
            })
            segBox.addView(r)
        }
        segBox.addView(label(
            if (segments.isEmpty()) "Aucun passage ajouté : le rendu utilise la sélection actuelle."
            else "Le rendu assemblera ces ${segments.size} passages.",
            13f, Pal.mut
        ))
    }

    /* ---- ouverture / fermeture ---- */

    private fun openEditor(d: File) {
        dir = d
        val meta = Store.readMeta(d)
        dur = meta.optLong("durationMs", 0L)
        previewing = false
        speed = 1f
        segments.clear()
        pendingPoster = null
        titleEdit.setText(meta.optString("title", d.name))
        status(editStatus, "")
        bar.visibility = View.GONE
        renderBtn.isEnabled = !busy
        updateRenderLabels()
        playBtn.text = "Lecture"
        gifBox.visibility = View.GONE
        refreshSegments()

        video.stopPlayback()
        video.setOnPreparedListener { mp ->
            if (dur <= 0L) dur = mp.duration.toLong()
            trim.duration = dur
            trim.start = 0L
            trim.end = dur
            trim.position = 0L
            trim.invalidate()
            updateTimes()
            video.seekTo(1)
        }
        video.setOnCompletionListener { playBtn.text = "Lecture"; previewing = false }
        video.setVideoURI(Uri.fromFile(File(d, "original.mp4")))

        if (File(d, "final.mp4").exists()) showFinal(d) else finalBox.visibility = View.GONE
        val gif = File(d, "export.gif")
        if (gif.exists()) showGif(gif)
        showSub(pgEditor)
    }

    private fun leaveEditor() {
        video.stopPlayback()
        finalVideo.stopPlayback()
        showTab(tab)
    }

    /* ---- rendu ---- */

    private fun targetFor(w: Int, h: Int, side: Int): Pair<Int, Int> {
        fun even(v: Float) = Math.round(v) and 1.inv()
        return if (h >= w) Pair(side, even(h * side.toFloat() / w)) else Pair(even(w * side.toFloat() / h), side)
    }

    private fun videoSize(f: File): Pair<Int, Int> {
        var w = 1080
        var h = 1920
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(f.path)
            w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: w
            h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: h
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
        } catch (e: Exception) {
        } finally {
            r.release()
        }
        return Pair(w, h)
    }

    /** Image transparente de la taille de la vidéo, avec le filigrane HEX-REC en haut à droite. */
    private fun watermarkBitmap(w: Int, h: Int): Bitmap {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val side = minOf(w, h)
        val logoSize = (side * 0.075f).toInt().coerceAtLeast(24)
        val margin = side * 0.035f
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        paint.textSize = logoSize * 0.5f
        paint.letterSpacing = 0.08f
        val text = "HEX-REC"
        val textW = paint.measureText(text)
        val pad = logoSize * 0.22f
        val boxW = pad + logoSize + pad + textW + pad * 1.4f
        val boxH = logoSize + pad * 1.2f
        val x = w - margin - boxW
        val y = margin
        paint.color = 0xB3000000.toInt()
        cv.drawRoundRect(RectF(x, y, x + boxW, y + boxH), boxH / 2, boxH / 2, paint)
        val logo = BitmapFactory.decodeResource(resources, R.drawable.hex_logo)
        if (logo != null) {
            val lx = x + pad
            val ly = y + (boxH - logoSize) / 2
            cv.drawBitmap(logo, null, RectF(lx, ly, lx + logoSize, ly + logoSize), null)
        }
        paint.color = 0xFFFFFFFF.toInt()
        cv.drawText(text, x + pad + logoSize + pad, y + boxH / 2 + paint.textSize * 0.36f, paint)
        return bmp
    }

    private fun buildItem(src: File, startMs: Long, endMs: Long, tw: Int, th: Int, spd: Float, wm: Bitmap?): EditedMediaItem {
        val mb = MediaItem.Builder().setUri(Uri.fromFile(src))
        if (endMs > startMs) {
            mb.setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(endMs)
                    .build()
            )
        }
        val video = ArrayList<Effect>()
        video.add(Presentation.createForWidthAndHeight(tw, th, Presentation.LAYOUT_SCALE_TO_FIT))
        if (spd != 1f) video.add(SpeedChangeEffect(spd))
        if (wm != null) {
            video.add(OverlayEffect(ImmutableList.of<TextureOverlay>(BitmapOverlay.createStaticBitmapOverlay(wm))))
        }
        val audio = ArrayList<AudioProcessor>()
        if (spd != 1f) {
            val sonic = SonicAudioProcessor()
            sonic.setSpeed(spd)
            audio.add(sonic)
        }
        return EditedMediaItem.Builder(mb.build()).setEffects(Effects(audio, video)).build()
    }

    private fun runTransformer(
        item: EditedMediaItem, out: File, bitrate: Int?,
        onProgress: (Float) -> Unit, onOk: () -> Unit, onErr: (String) -> Unit
    ) {
        out.delete()
        val builder = Transformer.Builder(this)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
        if (bitrate != null) {
            val enc = DefaultEncoderFactory.Builder(this)
                .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build())
                .build()
            builder.setEncoderFactory(enc)
        }
        val t = builder.addListener(object : Transformer.Listener {
            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                transformer = null
                onOk()
            }

            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                transformer = null
                onErr(exportException.message ?: "erreur inconnue")
            }
        }).build()
        transformer = t
        t.start(item, out.absolutePath)
        val holder = ProgressHolder()
        ui.postDelayed(object : Runnable {
            override fun run() {
                if (transformer !== t) return
                val s = t.getProgress(holder)
                if (s != Transformer.PROGRESS_STATE_NOT_STARTED) onProgress(holder.progress / 100f)
                ui.postDelayed(this, 300)
            }
        }, 300)
    }

    private fun render() {
        val d = dir ?: return
        if (busy) { toast("Une opération est déjà en cours."); return }
        val segs = currentSegments()
        val src = File(d, "original.mp4")
        val (w, h) = videoSize(src)
        val (tw, th) = targetFor(w, h, prefs.opt("render", "1080").toIntOrNull() ?: 1080)
        val wm = if (prefs.flag("watermark", true)) watermarkBitmap(tw, th) else null
        val spd = speed
        video.pause()
        playBtn.text = "Lecture"
        busy = true
        renderBtn.isEnabled = false
        bar.progress = 0
        bar.visibility = View.VISIBLE
        status(editStatus, "Rendu en cours… garde l'appli ouverte.")
        val parts = ArrayList<File>()

        fun fail(msg: String) {
            busy = false
            for (p in parts) p.delete()
            bar.visibility = View.GONE
            renderBtn.isEnabled = true
            status(editStatus, msg, Pal.err)
        }

        fun assemble() {
            status(editStatus, "Assemblage…")
            Thread {
                try {
                    val fin = File(d, "final.mp4")
                    if (parts.size == 1) {
                        fin.delete()
                        if (!parts[0].renameTo(fin)) throw IllegalStateException("fichier de sortie")
                    } else {
                        val tmp = File(d, ".final.tmp.mp4")
                        tmp.delete()
                        MediaOps.concat(parts, tmp)
                        fin.delete()
                        tmp.renameTo(fin)
                        for (p in parts) p.delete()
                    }
                    try { Publisher.makePoster(fin, File(d, "poster.jpg")) } catch (e: Exception) { }
                    File(d, "whatsapp.mp4").delete()
                    ui.post {
                        busy = false
                        bar.visibility = View.GONE
                        renderBtn.isEnabled = true
                        status(editStatus, "Rendu terminé : ${tw}×${th}, H.264.", Pal.ok)
                        showFinal(d)
                    }
                } catch (e: Exception) {
                    ui.post { fail("Assemblage impossible : ${e.message}") }
                }
            }.start()
        }

        fun step(i: Int) {
            if (i >= segs.size) { assemble(); return }
            val part = File(d, ".part$i.mp4")
            val item = buildItem(src, segs[i][0], segs[i][1], tw, th, spd, wm)
            runTransformer(
                item, part, null,
                { p -> bar.progress = (((i + p) / segs.size) * 100).toInt() },
                { parts.add(part); step(i + 1) },
                { m -> fail("Échec du rendu : $m") }
            )
        }
        step(0)
    }

    /* ---- version WhatsApp ---- */

    private fun compressWhatsApp() {
        val d = dir ?: return
        val fin = File(d, "final.mp4")
        if (!fin.exists()) { toast("Fais d'abord le rendu."); return }
        if (busy) { toast("Une opération est déjà en cours."); return }
        var durMs = 0L
        val mr = MediaMetadataRetriever()
        try {
            mr.setDataSource(fin.path)
            durMs = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
        } finally {
            mr.release()
        }
        if (durMs <= 0L) { toast("Durée illisible."); return }
        val vbps = ((15_000_000.0 * 8.0 / (durMs / 1000.0)) - 96_000.0).toInt().coerceIn(250_000, 2_500_000)
        val side = if (vbps < 900_000) 480 else 720
        val (w, h) = videoSize(fin)
        val (tw, th) = targetFor(w, h, side)
        val tmp = File(d, ".wa.tmp.mp4")
        busy = true
        waBtn.isEnabled = false
        waRow.visibility = View.GONE
        status(waStatus, "Compression en cours… 0 %")
        runTransformer(
            buildItem(fin, 0L, 0L, tw, th, 1f, null), tmp, vbps,
            { p -> status(waStatus, "Compression en cours… ${(p * 100).toInt()} %") },
            {
                busy = false
                waBtn.isEnabled = true
                val out = File(d, "whatsapp.mp4")
                out.delete()
                tmp.renameTo(out)
                showWhatsApp(out)
            },
            { m ->
                busy = false
                waBtn.isEnabled = true
                tmp.delete()
                status(waStatus, "Échec : $m", Pal.err)
            }
        )
    }

    private fun showWhatsApp(f: File) {
        val mb = f.length() / 1048576.0
        if (mb <= 16.0) {
            status(waStatus, String.format(Locale.US, "Prêt : %.1f Mo.", mb), Pal.ok)
        } else {
            status(waStatus, String.format(Locale.US, "Encore %.1f Mo : raccourcis la vidéo pour passer sous 16 Mo.", mb), Pal.err)
        }
        waRow.visibility = View.VISIBLE
    }

    /* ---- GIF ---- */

    private fun exportGif() {
        val d = dir ?: return
        if (busy) { toast("Une opération est déjà en cours."); return }
        val src = File(d, "original.mp4")
        val segs = currentSegments()
        val spd = speed
        val (vw, vh) = videoSize(src)
        val scale = 400f / maxOf(vw, vh)
        val gw = maxOf(2, (vw * scale).toInt() and 1.inv())
        val gh = maxOf(2, (vh * scale).toInt() and 1.inv())
        val fps = 10
        val stepUs = (1_000_000.0 * spd / fps).toLong().coerceAtLeast(1L)
        val times = ArrayList<Long>()
        for (s in segs) {
            var t = s[0] * 1000L
            val end = s[1] * 1000L
            while (t < end && times.size < 150) { times.add(t); t += stepUs }
        }
        if (times.isEmpty()) { toast("Sélection vide."); return }
        busy = true
        gifBtn.isEnabled = false
        gifBox.visibility = View.VISIBLE
        gifImg.setImageDrawable(null)
        status(gifStatus, "Création du GIF… 0 %")
        Thread {
            val outFile = File(d, "export.gif")
            val mr = MediaMetadataRetriever()
            try {
                mr.setDataSource(src.path)
                FileOutputStream(outFile).buffered().use { fos ->
                    val enc = GifEncoder(fos, gw, gh, 100 / fps)
                    enc.start()
                    var done = 0
                    for ((i, t) in times.withIndex()) {
                        val raw = mr.getScaledFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST, gw, gh)
                        if (raw != null) {
                            val bmp = if (raw.width != gw || raw.height != gh) Bitmap.createScaledBitmap(raw, gw, gh, true) else raw
                            val px = IntArray(gw * gh)
                            bmp.getPixels(px, 0, gw, 0, 0, gw, gh)
                            enc.addFrame(px)
                            done++
                        }
                        if (i % 5 == 0) {
                            val pct = (i + 1) * 100 / times.size
                            ui.post { status(gifStatus, "Création du GIF… $pct %") }
                        }
                    }
                    enc.finish()
                    if (done == 0) throw IllegalStateException("aucune image lue")
                }
                ui.post {
                    busy = false
                    gifBtn.isEnabled = true
                    showGif(outFile)
                }
            } catch (e: Exception) {
                outFile.delete()
                ui.post {
                    busy = false
                    gifBtn.isEnabled = true
                    status(gifStatus, "Échec du GIF : ${e.message}", Pal.err)
                }
            } finally {
                mr.release()
            }
        }.start()
    }

    private fun showGif(f: File) {
        gifBox.visibility = View.VISIBLE
        try {
            val dr = ImageDecoder.decodeDrawable(ImageDecoder.createSource(f))
            gifImg.setImageDrawable(dr)
            if (dr is AnimatedImageDrawable) {
                dr.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                dr.start()
            }
        } catch (e: Exception) {
        }
        status(gifStatus, String.format(Locale.US, "GIF prêt : %.1f Mo.", f.length() / 1048576.0), Pal.ok)
    }

    /* ---- rendu final, affiche, publication ---- */

    private fun showFinal(d: File) {
        finalBox.visibility = View.VISIBLE
        finalVideo.stopPlayback()
        finalPlayBtn.text = "Lecture"
        finalVideo.setOnPreparedListener { finalVideo.seekTo(1) }
        finalVideo.setVideoURI(Uri.fromFile(File(d, "final.mp4")))
        pubBtn.isEnabled = true
        status(pubStatus, if (prefs.configured()) "" else "Configure le serveur dans Réglages → Serveur de partage.")
        publishedUrl = try { JSONObject(File(d, "publish.json").readText()).getString("url") } catch (e: Exception) { null }
        urlText.text = publishedUrl ?: ""
        urlText.visibility = if (publishedUrl != null) View.VISIBLE else View.GONE
        linkBox.visibility = urlText.visibility

        pendingPoster = null
        val pf = File(d, "poster.jpg")
        if (pf.exists()) posterImg.setImageBitmap(BitmapFactory.decodeFile(pf.path)) else posterImg.setImageDrawable(null)
        Thread {
            var ms = 0L
            val mr = MediaMetadataRetriever()
            try {
                mr.setDataSource(File(d, "final.mp4").path)
                ms = mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            } catch (e: Exception) {
            } finally {
                mr.release()
            }
            ui.post {
                finalDurMs = ms
                posterSeek.max = ms.toInt().coerceAtLeast(1)
                posterSeek.progress = 0
            }
        }.start()

        val wa = File(d, "whatsapp.mp4")
        if (wa.exists()) showWhatsApp(wa) else { waRow.visibility = View.GONE; status(waStatus, "") }
    }

    private fun loadPosterAt(ms: Long) {
        val d = dir ?: return
        Thread {
            val b = try { Publisher.posterBitmap(File(d, "final.mp4"), ms) } catch (e: Exception) { null }
            if (b != null) ui.post { pendingPoster = b; posterImg.setImageBitmap(b) }
        }.start()
    }

    private fun usePoster() {
        val d = dir ?: return
        val b = pendingPoster
        if (b == null) { toast("Fais glisser le curseur pour choisir une image."); return }
        try {
            Publisher.savePoster(b, File(d, "poster.jpg"))
            toast("Image d'affiche enregistrée. Publie à nouveau pour l'envoyer.")
        } catch (e: Exception) {
            toast("Enregistrement impossible : ${e.message}")
        }
    }

    private fun publish() {
        val d = dir ?: return
        if (!prefs.configured()) {
            toast("Renseigne d'abord le serveur de partage.")
            showSub(pgPub)
            return
        }
        val title = titleEdit.text.toString().trim().ifEmpty { Store.readMeta(d).optString("title", d.name) }
        Store.writeMeta(d, Store.readMeta(d).put("title", title))
        pubBtn.isEnabled = false
        status(pubStatus, "Envoi vers le serveur…")
        Thread {
            try {
                val url = Publisher.publish(prefs, d, title) { f ->
                    ui.post { status(pubStatus, "Envoi… ${(f * 100).toInt().coerceIn(0, 100)} %") }
                }
                ui.post {
                    publishedUrl = url
                    urlText.text = url
                    urlText.visibility = View.VISIBLE
                    linkBox.visibility = View.VISIBLE
                    copyText(url)
                    status(pubStatus, "Publié. Lien copié dans le presse-papiers.", Pal.ok)
                    pubBtn.isEnabled = true
                }
            } catch (e: Exception) {
                ui.post {
                    status(pubStatus, "Échec : ${e.message}", Pal.err)
                    pubBtn.isEnabled = true
                }
            }
        }.start()
    }
}
