package app.rec

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputType
import android.text.SpannableString
import android.text.Spanned
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.Locale

class MainActivity : Activity() {

    companion object {
        const val REQ_PERMS = 1
        const val REQ_PROJ = 2
        const val REQ_IMPORT = 3
        const val ACT_RECORD = 0
        const val ACT_SHOT = 1
        const val CH_LINK = "https://whatsapp.com/channel/0029VbC8YkY7oQhiOiiSpy1z"
        const val EMAIL = "centralhex224@gmail.com"
        val C_BG = 0xFFFFFFFF.toInt()
        val C_PANEL = 0xFFF1F2F4.toInt()
        val C_LINE = 0xFFE6E7EA.toInt()
        val C_FG = 0xFF111214.toInt()
        val C_MUT = 0xFF7B7F87.toInt()
        val C_ACC = 0xFFE5231B.toInt()
        val C_ACC2 = 0xFFFF5A36.toInt()
        val C_OK = 0xFF1E9E5A.toInt()
        val WHITE = 0xFFFFFFFF.toInt()
    }

    private lateinit var prefs: Prefs
    private val ui = Handler(Looper.getMainLooper())

    // structure
    private lateinit var content: FrameLayout
    private lateinit var nav: LinearLayout
    private val navIcons = ArrayList<ImageView>()
    private val navLabels = ArrayList<TextView>()
    private lateinit var pgHome: FrameLayout
    private lateinit var pgPhotos: ScrollView
    private lateinit var pgTools: ScrollView
    private lateinit var pgSettings: ScrollView
    private lateinit var pgEditor: ScrollView
    private lateinit var pgPub: ScrollView
    private lateinit var pgAbout: ScrollView
    private var tab = 0
    private var pendingAction = ACT_RECORD

    // accueil
    private class Shortcut(val circle: FrameLayout, val icon: ImageView, val active: () -> Boolean)
    private val shortcuts = ArrayList<Shortcut>()
    private lateinit var storageText: TextView
    private lateinit var homeList: LinearLayout
    private lateinit var pillText: TextView
    private lateinit var toolsList: LinearLayout
    private lateinit var photosBox: LinearLayout

    // montage
    private var dir: File? = null
    private var dur = 0L
    private var previewing = false
    private var rendering = false
    private var transformer: Transformer? = null
    private var publishedUrl: String? = null
    private lateinit var titleEdit: EditText
    private lateinit var video: VideoView
    private lateinit var trim: TrimBar
    private lateinit var times: TextView
    private lateinit var playBtn: TextView
    private lateinit var renderBtn: TextView
    private lateinit var bar: ProgressBar
    private lateinit var editStatus: TextView
    private lateinit var finalBox: LinearLayout
    private lateinit var finalVideo: VideoView
    private lateinit var finalPlayBtn: TextView
    private lateinit var pubBtn: TextView
    private lateinit var pubStatus: TextView
    private lateinit var urlText: TextView
    private lateinit var copyBtn: TextView
    private lateinit var linkBox: LinearLayout

    // publication
    private val fieldViews = LinkedHashMap<String, EditText>()
    private lateinit var pubSettingsStatus: TextView
    private lateinit var serverRowValue: TextView

    /* ================= cycle de vie ================= */

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val shell = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C_BG) }
        content = FrameLayout(this)
        shell.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        nav = buildNav()
        shell.addView(nav, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(66)))
        setContentView(shell)

        buildHome()
        buildPhotos()
        buildTools()
        buildSettings()
        buildEditor()
        buildPub()
        buildAbout()
        for (p in listOf<View>(pgHome, pgPhotos, pgTools, pgSettings, pgEditor, pgPub, pgAbout)) {
            content.addView(p, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        showTab(0)
        handleIntent(intent)
        ui.post(tick)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        if (pgEditor.visibility != View.VISIBLE && pgPub.visibility != View.VISIBLE && pgAbout.visibility != View.VISIBLE) showTab(tab)
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        transformer?.cancel()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        when {
            pgEditor.visibility == View.VISIBLE -> leaveEditor()
            pgPub.visibility == View.VISIBLE -> showTab(3)
            pgAbout.visibility == View.VISIBLE -> showTab(3)
            tab != 0 -> showTab(0)
            else -> super.onBackPressed()
        }
    }

    private fun handleIntent(i: Intent?) {
        val name = i?.getStringExtra(RecorderService.EXTRA_OPEN) ?: return
        i?.removeExtra(RecorderService.EXTRA_OPEN)
        val d = File(Store.root(this), name)
        if (d.isDirectory && File(d, "original.mp4").exists()) openEditor(d)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (pgEditor.visibility == View.VISIBLE && video.isPlaying) {
                val p = video.currentPosition.toLong()
                trim.position = p
                if (previewing && p >= trim.end) {
                    video.pause()
                    video.seekTo(trim.end.toInt())
                    previewing = false
                    playBtn.text = "Lecture"
                }
                trim.invalidate()
            }
            ui.postDelayed(this, 60)
        }
    }

    /* ================= utilitaires d'interface ================= */

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(s: String, size: Float = 15f, color: Int = C_FG, bold: Boolean = false) =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun roundBg(color: Int, r: Int, strokeColor: Int = 0, strokeDp: Int = 0) = GradientDrawable().apply {
        cornerRadius = dp(r).toFloat()
        setColor(color)
        if (strokeDp > 0) setStroke(dp(strokeDp), strokeColor)
    }

    private fun ovalBg(color: Int, strokeColor: Int = 0, strokeDp: Int = 0) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(color)
        if (strokeDp > 0) setStroke(dp(strokeDp), strokeColor)
    }

    private fun gradientBg(r: Int) = GradientDrawable(
        GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(C_ACC2, C_ACC)
    ).apply { cornerRadius = dp(r).toFloat() }

    private fun icon(res: Int, tint: Int, size: Int = 24) = ImageView(this).apply {
        setImageResource(res)
        setColorFilter(tint)
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size))
    }

    private fun rounded(r: Int) = object : ViewOutlineProvider() {
        override fun getOutline(view: View, outline: Outline) {
            outline.setRoundRect(0, 0, view.width, view.height, dp(r).toFloat())
        }
    }

    /** Bouton texte : principal = dégradé rouge, sinon gris clair. */
    private fun button(s: String, primary: Boolean = false, onClick: () -> Unit) = TextView(this).apply {
        text = s
        textSize = 15f
        gravity = Gravity.CENTER
        setTypeface(typeface, Typeface.BOLD)
        setTextColor(if (primary) WHITE else C_FG)
        background = if (primary) gradientBg(24) else roundBg(C_PANEL, 24)
        setPadding(dp(14), dp(13), dp(14), dp(13))
        setOnClickListener { onClick() }
    }

    private fun LinearLayout.add(v: View, top: Int = 10, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT): View {
        addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h).apply { topMargin = dp(top) })
        return v
    }

    private fun row(vararg v: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEachIndexed { i, x ->
            addView(x, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) leftMargin = dp(8)
            })
        }
    }

    private fun column() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

    private fun page(c: LinearLayout, bottomPad: Int = 30) = ScrollView(this).apply {
        setBackgroundColor(C_BG)
        c.setPadding(dp(18), dp(20), dp(18), dp(bottomPad))
        addView(c)
    }

    private fun videoFrame(v: VideoView, heightDp: Int): FrameLayout = FrameLayout(this).apply {
        setBackgroundColor(0xFF000000.toInt())
        addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        minimumHeight = dp(heightDp)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun status(t: TextView, msg: String, color: Int = C_MUT) {
        t.text = msg
        t.setTextColor(color)
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun clock(ms: Long): String {
        val s = ms / 1000
        return String.format(Locale.ROOT, "%d:%02d", s / 60, s % 60)
    }

    private fun emptyState(msg: String): View = column().apply {
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(0, dp(60), 0, dp(20))
        addView(icon(R.drawable.ic_videocam, 0xFFD9DBE0.toInt(), 110))
        addView(label(msg, 14f, C_MUT).apply { gravity = Gravity.CENTER; setPadding(dp(20), dp(14), dp(20), 0) })
    }

    /* ================= navigation ================= */

    private fun buildNav(): LinearLayout {
        val n = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(C_BG)
            elevation = dp(8).toFloat()
            gravity = Gravity.CENTER_VERTICAL
        }
        fun item(idx: Int, res: Int, text: String) {
            val col = column().apply { gravity = Gravity.CENTER }
            val ic = icon(res, C_MUT, 24)
            val tv = label(text, 11f, C_MUT).apply { gravity = Gravity.CENTER; setPadding(0, dp(2), 0, 0) }
            col.addView(ic)
            col.addView(tv)
            navIcons.add(ic)
            navLabels.add(tv)
            col.setOnClickListener { showTab(idx) }
            n.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        }
        item(0, R.drawable.ic_videocam, "Vidéo")
        item(1, R.drawable.ic_image, "Photo")
        val plus = FrameLayout(this).apply {
            background = ovalBg(C_BG, C_FG, 2)
            addView(icon(R.drawable.ic_add, C_FG, 26), FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
            setOnClickListener { showPlusMenu() }
        }
        val plusWrap = FrameLayout(this)
        plusWrap.addView(plus, FrameLayout.LayoutParams(dp(52), dp(52), Gravity.CENTER))
        n.addView(plusWrap, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        item(2, R.drawable.ic_edit, "Modifier")
        item(3, R.drawable.ic_settings, "Paramètres")
        return n
    }

    private fun showTab(i: Int) {
        tab = i
        val pages = listOf<View>(pgHome, pgPhotos, pgTools, pgSettings)
        pages.forEachIndexed { k, p -> p.visibility = if (k == i) View.VISIBLE else View.GONE }
        pgEditor.visibility = View.GONE
        pgPub.visibility = View.GONE
        pgAbout.visibility = View.GONE
        nav.visibility = View.VISIBLE
        // l'indice des icônes de navigation suit l'ordre 0,1,2,3
        for (k in navIcons.indices) {
            val c = if (k == i) C_ACC else C_MUT
            navIcons[k].setColorFilter(c)
            navLabels[k].setTextColor(c)
        }
        when (i) {
            0 -> refreshHome()
            1 -> refreshPhotos()
            2 -> refreshTools()
        }
    }

    private fun showSub(v: View) {
        listOf<View>(pgHome, pgPhotos, pgTools, pgSettings, pgEditor, pgPub, pgAbout).forEach {
            it.visibility = if (it === v) View.VISIBLE else View.GONE
        }
        nav.visibility = View.GONE
    }

    private fun showPlusMenu() {
        val items = arrayOf("Enregistrer l'écran", "Capture d'écran", "Importer une vidéo de la galerie")
        AlertDialog.Builder(this).setItems(items) { _, which ->
            when (which) {
                0 -> onRecordClicked()
                1 -> startFlow(ACT_SHOT)
                2 -> importVideo()
            }
        }.show()
    }

    /* ================= accueil ================= */

    private fun buildHome() {
        val c = column()

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.hex_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
            outlineProvider = rounded(10)
            clipToOutline = true
        }
        head.addView(logo, LinearLayout.LayoutParams(dp(42), dp(42)))
        val brand = TextView(this).apply {
            val sp = SpannableString("HEX-REC")
            sp.setSpan(ForegroundColorSpan(C_FG), 0, 4, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            sp.setSpan(ForegroundColorSpan(C_ACC), 4, 7, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            text = sp
            textSize = 24f
            setTypeface(typeface, Typeface.BOLD_ITALIC)
        }
        head.addView(brand, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(10) })
        c.add(head, 0)

        // raccourcis ronds, comme XRecorder
        val sc = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val s1 = makeShortcut(R.drawable.ic_brush, "Brosse", { prefs.flag("brush", true) }) {
            val on = !prefs.flag("brush", true)
            prefs.setFlag("brush", on)
            if (on) {
                prefs.setFlag("ball", true)
                toast("Brosse : disponible dans la balle flottante pendant l'enregistrement.")
            }
        }
        val s2 = makeShortcut(R.drawable.ic_person, "Caméra faciale", { prefs.flag("cam", true) }) {
            prefs.setFlag("cam", !prefs.flag("cam", true))
        }
        val s3 = makeShortcut(R.drawable.ic_photo_camera, "Capture d'écran", { false }) { startFlow(ACT_SHOT) }
        val s4 = makeShortcut(R.drawable.ic_videocam, "Balle flottante", { prefs.flag("ball", true) }) {
            prefs.setFlag("ball", !prefs.flag("ball", true))
        }
        for (s in listOf(s1, s2, s3, s4)) sc.addView(s, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        c.add(sc, 22)

        val titleRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        titleRow.addView(label("Vidéo", 24f, bold = true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val chip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = roundBg(C_BG, 20, C_LINE, 1)
            setPadding(dp(10), dp(7), dp(10), dp(7))
        }
        chip.addView(icon(R.drawable.ic_phone, C_ACC, 18))
        storageText = label("", 13f, C_MUT).apply { setPadding(dp(8), 0, dp(4), 0) }
        chip.addView(storageText)
        chip.addView(icon(R.drawable.ic_chevron_right, C_MUT, 16))
        titleRow.addView(chip)
        c.add(titleRow, 24)

        homeList = column()
        c.add(homeList, 8)

        pgHome = FrameLayout(this)
        val scroll = page(c, 120)
        pgHome.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = gradientBg(30)
            elevation = dp(6).toFloat()
            setOnClickListener { onRecordClicked() }
        }
        pill.addView(icon(R.drawable.ic_videocam, WHITE, 24))
        pillText = label("Enregistrer", 19f, WHITE, true).apply { setPadding(dp(10), 0, 0, 0) }
        pill.addView(pillText)
        pgHome.addView(pill, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(58), Gravity.BOTTOM).apply {
            setMargins(dp(22), 0, dp(22), dp(16))
        })
    }

    private fun makeShortcut(res: Int, text: String, active: () -> Boolean, onTap: () -> Unit): LinearLayout {
        val circle = FrameLayout(this)
        val ic = icon(res, C_FG, 26)
        circle.addView(ic, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        val col = column().apply { gravity = Gravity.CENTER_HORIZONTAL }
        col.addView(circle, LinearLayout.LayoutParams(dp(62), dp(62)))
        col.addView(label(text, 12f, C_FG).apply { gravity = Gravity.CENTER; setPadding(0, dp(6), 0, 0) })
        col.setOnClickListener { onTap(); refreshShortcuts() }
        shortcuts.add(Shortcut(circle, ic, active))
        return col
    }

    private fun refreshShortcuts() {
        for (s in shortcuts) {
            val on = s.active()
            s.circle.background = ovalBg(if (on) C_ACC else C_PANEL)
            s.icon.setColorFilter(if (on) WHITE else C_FG)
        }
    }

    private fun storageInfo(): String = try {
        val st = StatFs(Environment.getDataDirectory().path)
        val total = st.blockCountLong * st.blockSizeLong
        val free = st.availableBlocksLong * st.blockSizeLong
        String.format(Locale.US, "%.1f/%.1fG", (total - free) / 1e9, total / 1e9)
    } catch (e: Exception) { "" }

    private fun refreshHome() {
        refreshShortcuts()
        storageText.text = storageInfo()
        pillText.text = if (RecorderService.running) "Arrêter" else "Enregistrer"
        homeList.removeAllViews()
        val list = Store.list(this)
        if (list.isEmpty()) homeList.addView(emptyState("Aucune vidéo pour l'instant.\nTouche « Enregistrer » pour commencer."))
        for (d in list.take(30)) homeList.addView(recordingRow(d))
    }

    private fun recordingRow(d: File): View {
        val meta = Store.readMeta(d)
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val thumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = roundBg(C_PANEL, 8)
            outlineProvider = rounded(8)
            clipToOutline = true
        }
        r.addView(thumb, LinearLayout.LayoutParams(dp(104), dp(66)))
        loadThumb(d, thumb)
        val info = column()
        info.addView(label(meta.optString("title", d.name), 15f, bold = true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        val tag = when {
            File(d, "publish.json").exists() -> " · publié"
            File(d, "final.mp4").exists() -> " · rendu"
            else -> ""
        }
        info.addView(label(d.name.take(10) + " · " + clock(meta.optLong("durationMs", 0L)) + tag, 12f, C_MUT).apply { setPadding(0, dp(4), 0, 0) })
        r.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(12) })
        r.setOnClickListener { openEditor(d) }
        r.setOnLongClickListener { confirmDelete(d); true }
        return r
    }

    private fun loadThumb(d: File, iv: ImageView) {
        Thread {
            val cache = File(d, "thumb.jpg")
            var bmp: Bitmap? = if (cache.exists()) BitmapFactory.decodeFile(cache.path) else null
            if (bmp == null) {
                val mr = MediaMetadataRetriever()
                try {
                    mr.setDataSource(File(d, "original.mp4").path)
                    val f = mr.getFrameAtTime(500_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: mr.getFrameAtTime(0)
                    if (f != null) {
                        val w = 320
                        val h = (f.height * w / f.width.toFloat()).toInt().coerceAtLeast(1)
                        val scaled = Bitmap.createScaledBitmap(f, w, h, true)
                        FileOutputStream(cache).use { scaled.compress(Bitmap.CompressFormat.JPEG, 80, it) }
                        bmp = scaled
                    }
                } catch (e: Exception) {
                } finally {
                    mr.release()
                }
            }
            val b = bmp
            if (b != null) ui.post { iv.setImageBitmap(b) }
        }.start()
    }

    private fun confirmDelete(d: File) {
        AlertDialog.Builder(this)
            .setTitle("Supprimer cet enregistrement ?")
            .setMessage("Les fichiers du téléphone seront effacés. La page déjà publiée reste en ligne.")
            .setPositiveButton("Supprimer") { _, _ -> d.deleteRecursively(); showTab(tab) }
            .setNegativeButton("Annuler", null)
            .show()
    }

    /* ================= enregistrement / capture ================= */

    private fun onRecordClicked() {
        if (RecorderService.running) {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
            return
        }
        startFlow(ACT_RECORD)
    }

    private fun startFlow(action: Int) {
        if (RecorderService.running) { toast("Un enregistrement est déjà en cours."); return }
        pendingAction = action
        val need = mutableListOf<String>()
        if (action == ACT_RECORD) {
            val cam = prefs.flag("cam", true)
            val mic = prefs.flag("mic", true)
            val ball = prefs.flag("ball", true)
            if ((cam || ball) && !Settings.canDrawOverlays(this)) {
                toast("Autorise « Affichage par-dessus les autres applis » (bulle webcam et balle), puis reviens.")
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return
            }
            if (cam && !granted(Manifest.permission.CAMERA)) need += Manifest.permission.CAMERA
            if (mic && !granted(Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
        }
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), REQ_PERMS)
            return
        }
        askProjection()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERMS) askProjection()   // le service désactive ce qui a été refusé
    }

    @Suppress("DEPRECATION")
    private fun askProjection() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJ)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_PROJ -> {
                if (resultCode != RESULT_OK || data == null) {
                    toast("Capture d'écran refusée.")
                    return
                }
                val i = Intent(this, RecorderService::class.java)
                    .setAction(if (pendingAction == ACT_SHOT) RecorderService.ACTION_SHOT else RecorderService.ACTION_START)
                    .putExtra(RecorderService.EXTRA_CODE, resultCode)
                    .putExtra(RecorderService.EXTRA_DATA, data)
                    .putExtra(RecorderService.EXTRA_CAM, prefs.flag("cam", true))
                    .putExtra(RecorderService.EXTRA_MIC, prefs.flag("mic", true))
                ContextCompat.startForegroundService(this, i)
                if (pendingAction == ACT_RECORD && prefs.flag("ball", true)) {
                    toast("Bouton flottant actif : touche-le pour pause, arrêt et brosse.")
                }
                ui.postDelayed({ moveTaskToBack(true) }, 600)
            }
            REQ_IMPORT -> {
                val uri = data?.data
                if (resultCode == RESULT_OK && uri != null) {
                    toast("Import en cours…")
                    Thread {
                        try {
                            val d = Store.importVideo(this, uri, "Vidéo importée")
                            ui.post { openEditor(d) }
                        } catch (e: Exception) {
                            ui.post { toast("Import impossible : ${e.message}") }
                        }
                    }.start()
                }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun importVideo() {
        val i = Intent(Intent.ACTION_GET_CONTENT).setType("video/*").addCategory(Intent.CATEGORY_OPENABLE)
        startActivityForResult(Intent.createChooser(i, "Choisir une vidéo"), REQ_IMPORT)
    }

    /* ================= onglet Photo ================= */

    private fun buildPhotos() {
        val c = column()
        c.add(label("Photo", 24f, bold = true), 0)
        photosBox = column()
        c.add(photosBox, 14)
        pgPhotos = page(c)
    }

    private fun refreshPhotos() {
        photosBox.removeAllViews()
        val shots = Store.listShots(this)
        if (shots.isEmpty()) {
            photosBox.addView(emptyState("Aucune capture d'écran.\nTouche « Capture d'écran » sur l'accueil."))
            return
        }
        for (pair in shots.chunked(2)) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for ((k, f) in pair.withIndex()) {
                r.addView(photoCell(f), LinearLayout.LayoutParams(0, dp(210), 1f).apply {
                    if (k > 0) leftMargin = dp(8)
                })
            }
            if (pair.size == 1) r.addView(View(this), LinearLayout.LayoutParams(0, dp(210), 1f).apply { leftMargin = dp(8) })
            photosBox.add(r, 8)
        }
    }

    private fun decode(f: File, maxW: Int): Bitmap? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, o)
        var s = 1
        while (o.outWidth / s > maxW) s *= 2
        return BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
    }

    private fun photoCell(f: File): ImageView {
        val iv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = roundBg(C_PANEL, 10)
            outlineProvider = rounded(10)
            clipToOutline = true
        }
        Thread { val b = decode(f, 600); if (b != null) ui.post { iv.setImageBitmap(b) } }.start()
        iv.setOnClickListener { viewPhoto(f) }
        iv.setOnLongClickListener {
            AlertDialog.Builder(this).setTitle("Supprimer cette capture ?")
                .setPositiveButton("Supprimer") { _, _ -> f.delete(); refreshPhotos() }
                .setNegativeButton("Annuler", null).show()
            true
        }
        return iv
    }

    private fun viewPhoto(f: File) {
        val dlg = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        val box = FrameLayout(this).apply { setBackgroundColor(0xFF000000.toInt()) }
        val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        Thread { val b = decode(f, 1600); if (b != null) ui.post { iv.setImageBitmap(b) } }.start()
        box.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        val btns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        btns.addView(button("Partager", true) { shareFile(f, "image/png") }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        btns.addView(button("Fermer") { dlg.dismiss() }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(10) })
        box.addView(btns, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply {
            setMargins(dp(18), 0, dp(18), dp(24))
        })
        dlg.setContentView(box)
        dlg.show()
    }

    /* ================= onglet Modifier ================= */

    private fun buildTools() {
        val c = column()
        c.add(label("Modifier", 24f, bold = true), 0)
        c.add(label("Découpe une vidéo, rends-la en MP4 1080p et publie-la.", 14f, C_MUT), 6)
        c.add(button("Importer une vidéo de la galerie", true) { importVideo() }, 18)
        c.add(label("Mes enregistrements", 17f, bold = true), 26)
        toolsList = column()
        c.add(toolsList, 6)
        pgTools = page(c)
    }

    private fun refreshTools() {
        toolsList.removeAllViews()
        val list = Store.list(this)
        if (list.isEmpty()) toolsList.addView(emptyState("Aucun enregistrement à modifier."))
        for (d in list.take(30)) toolsList.addView(recordingRow(d))
    }

    /* ================= onglet Paramètres ================= */

    private fun sectionTitle(c: LinearLayout, s: String) {
        c.add(label(s, 13f, C_ACC, true).apply { setPadding(0, dp(6), 0, 0) }, 22)
    }

    private fun settingRow(title: String, value: TextView, onTap: () -> Unit): View {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(14), 0, dp(14))
            setOnClickListener { onTap() }
        }
        r.addView(label(title, 16f), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(value)
        r.addView(icon(R.drawable.ic_chevron_right, C_MUT, 20))
        val wrap = column()
        wrap.addView(r)
        wrap.addView(View(this).apply { setBackgroundColor(C_LINE) }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(1)))
        return wrap
    }

    private fun cycleRow(c: LinearLayout, title: String, key: String, def: String, opts: List<Pair<String, String>>) {
        val value = label("", 14f, C_ACC).apply { setPadding(0, 0, dp(4), 0) }
        fun refresh() {
            val cur = prefs.opt(key, def)
            value.text = opts.firstOrNull { it.first == cur }?.second ?: opts[0].second
        }
        c.add(settingRow(title, value) {
            val cur = opts.indexOfFirst { it.first == prefs.opt(key, def) }
            prefs.put(key, opts[(cur + 1) % opts.size].first)
            refresh()
        }, 0)
        refresh()
    }

    private fun buildSettings() {
        val c = column()
        c.add(label("Paramètres", 24f, bold = true), 0)
        val onOff = listOf("1" to "Activé", "0" to "Désactivé")

        sectionTitle(c, "ENREGISTREMENT")
        cycleRow(c, "Résolution", "res", "1080", listOf("1080" to "1080p", "720" to "720p", "480" to "480p"))
        cycleRow(c, "Images par seconde", "fps", "30", listOf("30" to "30 i/s", "60" to "60 i/s"))
        cycleRow(c, "Qualité vidéo", "quality", "std", listOf("std" to "Standard", "high" to "Élevée"))
        cycleRow(c, "Décompte", "countdown", "3", listOf("0" to "Aucun", "3" to "3 s", "5" to "5 s", "10" to "10 s"))
        cycleRow(c, "Micro", "mic", "1", onOff)
        cycleRow(c, "Limite de durée", "limit", "0", listOf("0" to "Aucune", "5" to "5 min", "10" to "10 min", "30" to "30 min", "60" to "1 h"))
        cycleRow(c, "Secouer pour arrêter", "shake", "0", listOf("0" to "Désactivé", "1" to "Activé"))
        cycleRow(c, "Résolution du rendu", "render", "1080", listOf("1080" to "1080p", "720" to "720p"))

        sectionTitle(c, "WEBCAM")
        cycleRow(c, "Bulle webcam", "cam", "1", onOff)
        cycleRow(c, "Taille de la bulle", "bubble", "M", listOf("S" to "Petite", "M" to "Moyenne", "L" to "Grande"))
        cycleRow(c, "Caméra de la bulle", "camera", "front", listOf("front" to "Avant", "back" to "Arrière"))

        sectionTitle(c, "OUTILS")
        cycleRow(c, "Bouton flottant (pause, arrêt)", "ball", "1", onOff)
        cycleRow(c, "Brosse (dessin à l'écran)", "brush", "1", onOff)

        sectionTitle(c, "PUBLICATION")
        serverRowValue = label("", 14f, C_ACC).apply { setPadding(0, 0, dp(4), 0) }
        c.add(settingRow("Serveur de partage", serverRowValue) { showSub(pgPub) }, 0)
        serverRowValue.text = if (prefs.configured()) "Configuré" else "À configurer"

        sectionTitle(c, "COMMUNAUTÉ")
        val joinValue = label("Rejoindre", 14f, C_ACC).apply { setPadding(0, 0, dp(4), 0) }
        c.add(settingRow("CENTRAL-HEX", joinValue) { showSub(pgAbout) }, 0)

        sectionTitle(c, "À PROPOS")
        c.add(label("HEX-REC 1.2 · Enregistreur d'écran, montage et partage. Sans compte ni télémétrie.", 13f, C_MUT), 8)
        pgSettings = page(c)
    }

    /* ================= publication : réglages SFTP ================= */

    private fun buildPub() {
        val c = column()
        c.add(row(button("← Retour") { saveFields(); showTab(3) }), 0)
        c.add(label("Serveur de partage (SFTP)", 20f, bold = true), 16)
        c.add(label("La vidéo est envoyée sur ton VPS par SFTP. Rien d'autre ne sort du téléphone.", 13f, C_MUT), 4)

        data class F(val key: String, val title: String, val hint: String, val kind: Int, val multi: Boolean = false)
        val uri = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        val pass = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        val fields = listOf(
            F("author", "Ton nom (affiché sur la page)", "Ton Nom", InputType.TYPE_CLASS_TEXT),
            F("baseUrl", "URL de partage", "https://share.example.com", uri),
            F("host", "Serveur SSH", "ton-vps.example.com", uri),
            F("port", "Port", "22", InputType.TYPE_CLASS_NUMBER),
            F("user", "Utilisateur SSH", "share", uri),
            F("dataDir", "Dossier distant", "/srv/share/data", uri),
            F("password", "Mot de passe SSH (si pas de clé)", "", pass),
            F("key", "Clé privée (optionnel, RSA/ECDSA recommandé)", "-----BEGIN OPENSSH PRIVATE KEY-----",
                InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE, true),
            F("passphrase", "Mot de passe de la clé (si chiffrée)", "", pass)
        )
        for (f in fields) {
            c.add(label(f.title, 13f, C_MUT), 14)
            val e = EditText(this).apply {
                hint = f.hint
                setHintTextColor(0xFFB5B8BF.toInt())
                setTextColor(C_FG)
                inputType = f.kind
                setText(prefs.get(f.key))
                if (f.multi) {
                    minLines = 4
                    maxLines = 8
                    gravity = Gravity.TOP or Gravity.START
                    textSize = 12f
                } else {
                    isSingleLine = true
                }
            }
            fieldViews[f.key] = e
            c.add(e, 2)
        }
        pubSettingsStatus = label("", 14f, C_MUT)
        c.add(button("Enregistrer", true) {
            saveFields()
            status(pubSettingsStatus, "Réglages enregistrés.", C_OK)
        }, 20)
        c.add(button("Tester la connexion") { testConnection() }, 8)
        c.add(button("Oublier la clé du serveur") {
            prefs.put("known_hosts", "")
            status(pubSettingsStatus, "Clé du serveur oubliée.")
        }, 8)
        c.add(pubSettingsStatus, 10)
        pgPub = page(c)
    }

    private fun saveFields() {
        for ((k, e) in fieldViews) {
            val raw = e.text.toString()
            prefs.put(k, if (k == "password" || k == "passphrase") raw else raw.trim())
        }
        serverRowValue.text = if (prefs.configured()) "Configuré" else "À configurer"
    }

    private fun testConnection() {
        saveFields()
        status(pubSettingsStatus, "Connexion…")
        Thread {
            val msg = try { Publisher.test(prefs) to C_OK } catch (e: Exception) { ("Échec : ${e.message}") to C_ACC }
            ui.post { status(pubSettingsStatus, msg.first, msg.second) }
        }.start()
    }

    /* ================= montage + publication ================= */

    private fun buildEditor() {
        val c = column()
        c.add(row(button("← Retour") { leaveEditor() }), 0)

        titleEdit = EditText(this).apply {
            hint = "Titre de la vidéo"
            setHintTextColor(0xFFB5B8BF.toInt())
            setTextColor(C_FG)
            textSize = 19f
            isSingleLine = true
        }
        c.add(titleEdit, 12)

        video = VideoView(this)
        c.add(videoFrame(video, 360), 10, dp(360))

        trim = TrimBar(this)
        trim.onDrag = { which ->
            val t = when (which) { 1 -> trim.start; 2 -> trim.end; else -> trim.position }
            video.pause()
            previewing = false
            playBtn.text = "Lecture"
            video.seekTo(t.toInt())
            updateTimes()
        }
        c.add(trim, 8)
        times = label("", 13f, C_MUT)
        c.add(times, 0)

        playBtn = button("Lecture") { togglePlay() }
        val prev = button("Prévisualiser") {
            previewing = true
            video.seekTo(trim.start.toInt())
            video.start()
            playBtn.text = "Pause"
        }
        val setIn = button("Entrée ici") {
            trim.start = minOf(video.currentPosition.toLong(), trim.end - 200).coerceAtLeast(0L)
            trim.invalidate(); updateTimes()
        }
        val setOut = button("Sortie ici") {
            trim.end = maxOf(video.currentPosition.toLong(), trim.start + 200).coerceAtMost(dur)
            trim.invalidate(); updateTimes()
        }
        c.add(row(playBtn, prev), 10)
        c.add(row(setIn, setOut), 8)

        renderBtn = button("Rendre en MP4 1080p", true) { render() }
        c.add(renderBtn, 16)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        c.add(bar, 10)
        editStatus = label("", 14f, C_MUT)
        c.add(editStatus, 6)

        finalBox = column()
        finalBox.add(label("Rendu final", 18f, bold = true), 0)
        finalVideo = VideoView(this)
        finalBox.add(videoFrame(finalVideo, 300), 10, dp(300))
        finalPlayBtn = button("Lecture") {
            if (finalVideo.isPlaying) { finalVideo.pause(); finalPlayBtn.text = "Lecture" }
            else { finalVideo.start(); finalPlayBtn.text = "Pause" }
        }
        finalVideo.setOnCompletionListener { finalPlayBtn.text = "Lecture" }
        pubBtn = button("Publier", true) { publish() }
        finalBox.add(row(finalPlayBtn, pubBtn), 10)
        finalBox.add(row(
            button("Partager la vidéo") { dir?.let { shareFile(File(it, "final.mp4"), "video/mp4") } },
            button("Dans la galerie") { exportToGallery() }
        ), 8)
        pubStatus = label("", 14f, C_MUT)
        finalBox.add(pubStatus, 10)
        urlText = label("", 15f, C_ACC, true).apply {
            setOnClickListener { publishedUrl?.let { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it))) } }
        }
        finalBox.add(urlText, 6)
        copyBtn = button("Copier le lien") { publishedUrl?.let { copyLink(it) } }
        linkBox = row(copyBtn, button("Partager le lien") { publishedUrl?.let { shareText(it) } })
        finalBox.add(linkBox, 8)
        c.add(finalBox, 26)
        finalBox.visibility = View.GONE

        pgEditor = page(c)
    }

    private fun updateTimes() {
        times.text = "Entrée ${Store.fmt(trim.start)}    Durée ${Store.fmt(trim.end - trim.start)}    Sortie ${Store.fmt(trim.end)}"
    }

    private fun togglePlay() {
        if (video.isPlaying) {
            video.pause(); previewing = false; playBtn.text = "Lecture"
        } else {
            video.start(); playBtn.text = "Pause"
        }
    }

    private fun openEditor(d: File) {
        dir = d
        val meta = Store.readMeta(d)
        dur = meta.optLong("durationMs", 0L)
        previewing = false
        titleEdit.setText(meta.optString("title", d.name))
        status(editStatus, "")
        bar.visibility = View.GONE
        renderBtn.isEnabled = true
        renderBtn.text = "Rendre en MP4 ${prefs.opt("render", "1080")}p"
        playBtn.text = "Lecture"

        video.stopPlayback()
        video.setOnPreparedListener { mp ->
            if (dur <= 0L) dur = mp.duration.toLong()
            trim.duration = dur
            trim.start = 0L
            trim.end = dur
            trim.position = 0L
            trim.invalidate()
            updateTimes()
            video.seekTo(1)
        }
        video.setOnCompletionListener { playBtn.text = "Lecture"; previewing = false }
        video.setVideoURI(Uri.fromFile(File(d, "original.mp4")))

        if (File(d, "final.mp4").exists()) showFinal(d) else finalBox.visibility = View.GONE
        showSub(pgEditor)
    }

    private fun leaveEditor() {
        video.stopPlayback()
        finalVideo.stopPlayback()
        showTab(tab)
    }

    private fun target(w: Int, h: Int): Pair<Int, Int> {
        // le petit côté fait 1080 (ou 720) px, le ratio est conservé, sans bandes noires
        val side = prefs.opt("render", "1080").toIntOrNull() ?: 1080
        fun even(v: Float) = Math.round(v) and 1.inv()
        return if (h >= w) Pair(side, even(h * side.toFloat() / w)) else Pair(even(w * side.toFloat() / h), side)
    }

    private fun render() {
        val d = dir ?: return
        if (rendering) return
        val src = File(d, "original.mp4")
        val tmp = File(d, ".final.tmp.mp4")
        tmp.delete()

        var w = 1080
        var h = 1920
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(src.path)
            w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: w
            h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: h
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
        } catch (e: Exception) {
        } finally {
            r.release()
        }
        val (tw, th) = target(w, h)

        video.pause()
        playBtn.text = "Lecture"
        val clip = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(trim.start)
            .setEndPositionMs(trim.end)
            .build()
        val item = MediaItem.Builder().setUri(Uri.fromFile(src)).setClippingConfiguration(clip).build()
        val effects = Effects(
            emptyList<AudioProcessor>(),
            listOf<Effect>(Presentation.createForWidthAndHeight(tw, th, Presentation.LAYOUT_SCALE_TO_FIT))
        )
        val edited = EditedMediaItem.Builder(item).setEffects(effects).build()

        val t = Transformer.Builder(this)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    rendering = false
                    val fin = File(d, "final.mp4")
                    fin.delete()
                    tmp.renameTo(fin)
                    status(editStatus, "Rendu terminé. Création de l'affiche…")
                    Thread {
                        try { Publisher.makePoster(fin, File(d, "poster.jpg")) } catch (e: Exception) { }
                        ui.post {
                            bar.visibility = View.GONE
                            renderBtn.isEnabled = true
                            status(editStatus, "Rendu terminé : ${tw}×${th}, H.264.", C_OK)
                            showFinal(d)
                        }
                    }.start()
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    rendering = false
                    tmp.delete()
                    bar.visibility = View.GONE
                    renderBtn.isEnabled = true
                    status(editStatus, "Échec du rendu : ${exportException.message}", C_ACC)
                }
            })
            .build()
        transformer = t
        rendering = true
        renderBtn.isEnabled = false
        bar.progress = 0
        bar.visibility = View.VISIBLE
        status(editStatus, "Rendu en cours… garde l'appli ouverte.")
        t.start(edited, tmp.absolutePath)

        val holder = ProgressHolder()
        ui.postDelayed(object : Runnable {
            override fun run() {
                if (!rendering) return
                val s = t.getProgress(holder)
                if (s != Transformer.PROGRESS_STATE_NOT_STARTED) bar.progress = holder.progress
                ui.postDelayed(this, 300)
            }
        }, 300)
    }

    private fun showFinal(d: File) {
        finalBox.visibility = View.VISIBLE
        finalVideo.stopPlayback()
        finalPlayBtn.text = "Lecture"
        finalVideo.setOnPreparedListener { finalVideo.seekTo(1) }
        finalVideo.setVideoURI(Uri.fromFile(File(d, "final.mp4")))
        pubBtn.isEnabled = true
        status(pubStatus, if (prefs.configured()) "" else "Configure le serveur dans Paramètres → Serveur de partage.")
        publishedUrl = try { JSONObject(File(d, "publish.json").readText()).getString("url") } catch (e: Exception) { null }
        urlText.text = publishedUrl ?: ""
        urlText.visibility = if (publishedUrl != null) View.VISIBLE else View.GONE
        linkBox.visibility = urlText.visibility
    }

    private fun copyLink(url: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("lien", url))
    }

    private fun publish() {
        val d = dir ?: return
        if (!prefs.configured()) {
            toast("Renseigne d'abord le serveur de partage.")
            showSub(pgPub)
            return
        }
        val title = titleEdit.text.toString().trim().ifEmpty { Store.readMeta(d).optString("title", d.name) }
        Store.writeMeta(d, Store.readMeta(d).put("title", title))
        pubBtn.isEnabled = false
        status(pubStatus, "Envoi vers le serveur…")
        Thread {
            try {
                val url = Publisher.publish(prefs, d, title) { f ->
                    ui.post { status(pubStatus, "Envoi… ${(f * 100).toInt().coerceIn(0, 100)} %") }
                }
                ui.post {
                    publishedUrl = url
                    urlText.text = url
                    urlText.visibility = View.VISIBLE
                    linkBox.visibility = View.VISIBLE
                    copyLink(url)
                    status(pubStatus, "Publié. Lien copié dans le presse-papiers.", C_OK)
                    pubBtn.isEnabled = true
                }
            } catch (e: Exception) {
                ui.post {
                    status(pubStatus, "Échec : ${e.message}", C_ACC)
                    pubBtn.isEnabled = true
                }
            }
        }.start()
    }

    /* ================= partage / liens ================= */

    private fun shareFile(f: File, mime: String) {
        try {
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", f)
            val i = Intent(Intent.ACTION_SEND).setType(mime)
                .putExtra(Intent.EXTRA_STREAM, uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Partager"))
        } catch (e: Exception) {
            toast("Partage impossible : ${e.message}")
        }
    }

    private fun shareText(text: String) {
        try {
            val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
            startActivity(Intent.createChooser(i, "Partager"))
        } catch (e: Exception) {
            toast("Partage impossible : ${e.message}")
        }
    }

    private fun openUrl(url: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (e: Exception) { toast("Impossible d'ouvrir le lien.") }
    }

    private fun copyText(text: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("texte", text))
        toast("Copié")
    }

    private fun sendMail() {
        try {
            startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$EMAIL")))
        } catch (e: Exception) {
            copyText(EMAIL)
        }
    }

    /* ================= page CENTRAL-HEX ================= */

    private fun bullet(c: LinearLayout, title: String, text: String) {
        c.add(label(title, 15f, bold = true), 12)
        c.add(label(text, 14f, C_MUT), 2)
    }

    private fun infoLine(c: LinearLayout, name: String, value: String, onTap: (() -> Unit)? = null) {
        c.add(label(name, 12f, C_MUT), 12)
        val v = label(value, 16f, if (onTap != null) C_ACC else C_FG, true)
        if (onTap != null) v.setOnClickListener { onTap() }
        c.add(v, 2)
    }

    private fun buildAbout() {
        val c = column()
        c.add(row(button("← Retour") { showTab(3) }), 0)

        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.hex_logo)
            outlineProvider = rounded(12)
            clipToOutline = true
        }
        head.addView(logo, LinearLayout.LayoutParams(dp(56), dp(56)))
        val t = column()
        t.addView(label("CENTRAL-HEX", 22f, bold = true))
        t.addView(label("La communauté Tech & Digital", 13f, C_ACC))
        head.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { leftMargin = dp(12) })
        c.add(head, 16)

        c.add(label("La plateforme ultime pour les passionnés de technologie et de digital.", 15f), 16)

        c.add(label("Ce que tu y trouves", 17f, bold = true), 22)
        bullet(c, "Explorer la tech et l'IA", "Bots, automatisation, intelligence artificielle.")
        bullet(c, "Créer ton univers digital", "Sites web, outils, projets en ligne.")
        bullet(c, "Développer et automatiser tes idées", "Bots WhatsApp, scripts, solutions pratiques.")
        bullet(c, "Accéder à des ressources exclusives", "Guides, tutoriels, astuces avancées.")
        bullet(c, "Innover et partager", "Idées business, projets collaboratifs, challenges créatifs.")

        c.add(label("Notre mission", 17f, bold = true), 24)
        c.add(label("Construire une communauté forte, active et innovante, où l'apprentissage se transforme en action. Ici, on ne reste pas spectateur : on apprend, on applique, on évolue.", 14f, C_MUT), 6)

        c.add(label("Contact", 17f, bold = true), 24)
        infoLine(c, "Créateur", "Ibrahima Sory Sacko")
        infoLine(c, "Pseudo", "SALGADO")
        infoLine(c, "Adresse e-mail", EMAIL) { sendMail() }
        infoLine(c, "Chaîne WhatsApp", CH_LINK) { openUrl(CH_LINK) }

        c.add(button("Rejoindre la chaîne WhatsApp", true) { openUrl(CH_LINK) }, 22)
        c.add(row(button("Écrire un e-mail") { sendMail() }, button("Copier l'e-mail") { copyText(EMAIL) }), 8)
        c.add(button("Partager la chaîne") { shareText("Rejoins CENTRAL-HEX, la communauté Tech & Digital : $CH_LINK") }, 8)
        c.add(label("CENTRAL-HEX · Où la technologie rencontre la créativité.", 13f, C_MUT).apply { gravity = Gravity.CENTER }, 26)
        pgAbout = page(c)
    }

    private fun exportToGallery() {
        val d = dir ?: return
        val f = File(d, "final.mp4")
        if (!f.exists()) return
        try {
            val v = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, d.name + ".mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/HEX-REC")
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
                ?: throw IllegalStateException("MediaStore indisponible")
            contentResolver.openOutputStream(uri)?.use { out -> FileInputStream(f).use { it.copyTo(out) } }
            toast("Enregistré dans Films/HEX-REC")
        } catch (e: Exception) {
            toast("Export impossible : ${e.message}")
        }
    }
}
