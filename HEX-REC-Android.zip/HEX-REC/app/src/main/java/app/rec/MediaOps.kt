package app.rec

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.nio.ByteBuffer

object MediaOps {
    /**
     * Assemble des MP4 de même encodage (issus du même rendu) bout à bout, sans ré-encodage.
     */
    fun concat(parts: List<File>, out: File) {
        val muxer = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var vOut = -1
        var aOut = -1
        val first = MediaExtractor()
        first.setDataSource(parts[0].path)
        for (i in 0 until first.trackCount) {
            val f = first.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("video/") && vOut < 0) vOut = muxer.addTrack(f)
            else if (mime.startsWith("audio/") && aOut < 0) aOut = muxer.addTrack(f)
        }
        first.release()
        muxer.start()

        val buf = ByteBuffer.allocate(2 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        var offset = 0L
        for (p in parts) {
            val ex = MediaExtractor()
            ex.setDataSource(p.path)
            var vIn = -1
            var aIn = -1
            for (i in 0 until ex.trackCount) {
                val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("video/") && vIn < 0) vIn = i
                else if (mime.startsWith("audio/") && aIn < 0) aIn = i
            }
            var maxEnd = 0L
            for (pair in listOf(Pair(vIn, vOut), Pair(aIn, aOut))) {
                val inIdx = pair.first
                val outIdx = pair.second
                if (inIdx < 0 || outIdx < 0) continue
                ex.selectTrack(inIdx)
                while (true) {
                    buf.clear()
                    val size = ex.readSampleData(buf, 0)
                    if (size < 0) break
                    val t = ex.sampleTime
                    info.set(0, size, t + offset, ex.sampleFlags)
                    muxer.writeSampleData(outIdx, buf, info)
                    if (t > maxEnd) maxEnd = t
                    ex.advance()
                }
                ex.unselectTrack(inIdx)
            }
            ex.release()
            offset += maxEnd + 33_000L
        }
        muxer.stop()
        muxer.release()
    }
}
