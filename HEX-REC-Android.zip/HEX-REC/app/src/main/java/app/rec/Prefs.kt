package app.rec

import android.content.Context

/** Réglages (stockage privé de l'application). Les booléens sont stockés "1" / "0". */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun get(k: String): String = sp.getString(k, "") ?: ""
    fun put(k: String, v: String) { sp.edit().putString(k, v).apply() }

    fun opt(k: String, def: String): String = get(k).ifEmpty { def }
    fun flag(k: String, def: Boolean = true): Boolean = opt(k, if (def) "1" else "0") == "1"
    fun setFlag(k: String, v: Boolean) = put(k, if (v) "1" else "0")

    fun configured(): Boolean =
        get("baseUrl").startsWith("http") && get("host").isNotBlank() && get("user").isNotBlank() &&
            get("dataDir").startsWith("/") && (get("password").isNotEmpty() || get("key").isNotBlank())
}
