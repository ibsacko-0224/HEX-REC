package app.rec

import java.io.OutputStream

/**
 * Encodeur GIF animé minimal : palette fixe de 256 couleurs (cube 6×6×6 + 40 gris), tramage ordonné,
 * compression LZW. Pas de dépendance externe.
 */
class GifEncoder(private val out: OutputStream, private val w: Int, private val h: Int, private val delayCs: Int) {

    private companion object {
        val BAYER = intArrayOf(0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5)
    }

    private fun w16(v: Int) {
        out.write(v and 0xFF)
        out.write((v shr 8) and 0xFF)
    }

    private fun clamp(v: Int) = if (v < 0) 0 else if (v > 255) 255 else v

    fun start() {
        out.write("GIF89a".toByteArray(Charsets.US_ASCII))
        w16(w)
        w16(h)
        out.write(0xF7)   // palette globale de 256 couleurs
        out.write(0)
        out.write(0)
        for (i in 0 until 256) {
            if (i < 216) {
                out.write((i / 36) * 51)
                out.write(((i / 6) % 6) * 51)
                out.write((i % 6) * 51)
            } else {
                val g = ((i - 216) * 255) / 39
                out.write(g); out.write(g); out.write(g)
            }
        }
        // boucle infinie
        out.write(0x21); out.write(0xFF); out.write(11)
        out.write("NETSCAPE2.0".toByteArray(Charsets.US_ASCII))
        out.write(3); out.write(1); out.write(0); out.write(0); out.write(0)
    }

    fun addFrame(px: IntArray) {
        val idx = ByteArray(w * h)
        var p = 0
        for (y in 0 until h) {
            for (x in 0 until w) {
                val c = px[p]
                val t = (BAYER[((y and 3) shl 2) or (x and 3)] - 8) * 3
                val r = clamp(((c shr 16) and 0xFF) + t)
                val g = clamp(((c shr 8) and 0xFF) + t)
                val b = clamp((c and 0xFF) + t)
                val mx = maxOf(r, maxOf(g, b))
                val mn = minOf(r, minOf(g, b))
                val v = if (mx - mn < 14) {
                    216 + (((r + g + b) / 3) * 39 + 127) / 255
                } else {
                    ((r + 25) / 51) * 36 + ((g + 25) / 51) * 6 + ((b + 25) / 51)
                }
                idx[p] = v.toByte()
                p++
            }
        }
        // extension de contrôle graphique (durée de l'image)
        out.write(0x21); out.write(0xF9); out.write(4); out.write(0x04)
        w16(delayCs); out.write(0); out.write(0)
        // descripteur d'image
        out.write(0x2C); w16(0); w16(0); w16(w); w16(h); out.write(0)
        out.write(8)
        val bw = BitWriter(out)
        lzw(idx, bw)
        bw.finish()
    }

    fun finish() {
        out.write(0x3B)
        out.flush()
    }

    private class BitWriter(val out: OutputStream) {
        private var acc = 0
        private var n = 0
        private val buf = ByteArray(255)
        private var len = 0

        fun write(code: Int, size: Int) {
            acc = acc or (code shl n)
            n += size
            while (n >= 8) {
                put(acc and 0xFF)
                acc = acc ushr 8
                n -= 8
            }
        }

        private fun put(b: Int) {
            buf[len++] = b.toByte()
            if (len == 255) flushBlock()
        }

        private fun flushBlock() {
            if (len > 0) {
                out.write(len)
                out.write(buf, 0, len)
                len = 0
            }
        }

        fun finish() {
            if (n > 0) put(acc and 0xFF)
            acc = 0
            n = 0
            flushBlock()
            out.write(0)
        }
    }

    private fun lzw(data: ByteArray, w: BitWriter) {
        val initBits = 9
        val clear = 256
        val eoi = 257
        var nBits = initBits
        var maxCode = (1 shl nBits) - 1
        var freeEnt = 258
        var clearFlag = false
        val dict = HashMap<Int, Int>(8192)

        fun output(code: Int) {
            w.write(code, nBits)
            if (freeEnt > maxCode || clearFlag) {
                if (clearFlag) {
                    nBits = initBits
                    maxCode = (1 shl nBits) - 1
                    clearFlag = false
                } else {
                    nBits++
                    maxCode = if (nBits == 12) 4096 else (1 shl nBits) - 1
                }
            }
        }

        fun clearBlock() {
            dict.clear()
            freeEnt = 258
            clearFlag = true
            output(clear)
        }

        output(clear)
        var ent = data[0].toInt() and 0xFF
        for (i in 1 until data.size) {
            val c = data[i].toInt() and 0xFF
            val key = (ent shl 8) or c
            val code = dict[key]
            if (code != null) {
                ent = code
                continue
            }
            output(ent)
            ent = c
            if (freeEnt < 4096) {
                dict[key] = freeEnt
                freeEnt++
            } else {
                clearBlock()
            }
        }
        output(ent)
        output(eoi)
    }
}
