package app.rec

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.media.MediaMetadataRetriever
import com.jcraft.jsch.ChannelSftp
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import com.jcraft.jsch.SftpException
import com.jcraft.jsch.SftpProgressMonitor
import com.jcraft.jsch.UserInfo
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Publication par SFTP, avec la même arborescence que la version bureau :
 * <dataDir>/<id>/video.mp4, poster.jpg, meta.json (envoyé en dernier).
 * Clé du serveur : confiance à la première connexion (TOFU), puis vérifiée.
 */
object Publisher {

    private class Info : UserInfo {
        override fun getPassphrase(): String? = null
        override fun getPassword(): String? = null
        override fun promptPassword(message: String?) = false
        override fun promptPassphrase(message: String?) = false
        override fun promptYesNo(message: String?) = true   // première connexion uniquement
        override fun showMessage(message: String?) {}
    }

    private class Conn(val session: Session, val sftp: ChannelSftp) {
        fun close() {
            try { sftp.disconnect() } catch (e: Exception) { }
            try { session.disconnect() } catch (e: Exception) { }
        }
    }

    private fun connect(p: Prefs): Conn {
        val jsch = JSch()
        val known = p.get("known_hosts")
        if (known.isNotBlank()) jsch.setKnownHosts(ByteArrayInputStream(known.toByteArray()))

        val key = p.get("key").trim().replace("\r", "")
        if (key.isNotEmpty()) {
            val pass = p.get("passphrase")
            jsch.addIdentity("rec-key", (key + "\n").toByteArray(), null, if (pass.isEmpty()) null else pass.toByteArray())
        }
        val port = p.get("port").trim().toIntOrNull() ?: 22
        val s = jsch.getSession(p.get("user").trim(), p.get("host").trim(), port)
        val pw = p.get("password")
        if (pw.isNotEmpty()) s.setPassword(pw)
        s.setConfig("StrictHostKeyChecking", "ask")
        s.setConfig("PreferredAuthentications", if (key.isNotEmpty()) "publickey,password" else "password,keyboard-interactive")
        s.userInfo = Info()
        try {
            s.connect(15000)
        } catch (e: Exception) {
            val m = e.message ?: ""
            if (m.contains("HostKey has been changed", true) || m.contains("HOST IDENTIFICATION", true))
                throw IllegalStateException("La clé du serveur a changé. Si c'est normal, « Oublier la clé du serveur » dans les réglages.")
            throw e
        }
        val hk = s.hostKey
        val line = "${hk.host} ${hk.type} ${hk.key}"
        if (!known.lines().contains(line)) p.put("known_hosts", (known.trim() + "\n" + line).trim())

        val ch = s.openChannel("sftp") as ChannelSftp
        ch.connect(15000)
        return Conn(s, ch)
    }

    private fun mkdirs(ch: ChannelSftp, path: String) {
        var cur = ""
        for (part in path.split("/").filter { it.isNotEmpty() }) {
            cur += "/$part"
            try {
                ch.stat(cur)
            } catch (e: SftpException) {
                ch.mkdir(cur)
                try { ch.chmod(493, cur) } catch (x: Exception) { }   // 0755
            }
        }
    }

    fun test(p: Prefs): String {
        val c = connect(p)
        try {
            c.sftp.stat(p.get("dataDir").trim())
            return "Connexion OK, dossier distant trouvé."
        } catch (e: SftpException) {
            return "Connexion OK, mais le dossier distant est introuvable (il sera créé si les droits le permettent)."
        } finally {
            c.close()
        }
    }

    fun publish(p: Prefs, dir: File, title: String, onProgress: (Float) -> Unit): String {
        val mp4 = File(dir, "final.mp4")
        val poster = File(dir, "poster.jpg")
        require(mp4.exists()) { "Fais d'abord le rendu MP4" }

        val pubFile = File(dir, "publish.json")
        val id = try { JSONObject(pubFile.readText()).getString("id") } catch (e: Exception) { randomId() }
        val base = p.get("baseUrl").trim().trimEnd('/')
        val remote = p.get("dataDir").trim().trimEnd('/') + "/" + id
        val share = JSONObject().put("id", id).put("title", title).put("author", p.get("author")).put("publishedAt", iso())

        val c = connect(p)
        try {
            mkdirs(c.sftp, remote)
            val size = mp4.length().coerceAtLeast(1L)
            c.sftp.put(mp4.absolutePath, "$remote/video.mp4", object : SftpProgressMonitor {
                var sent = 0L
                override fun init(op: Int, src: String?, dest: String?, max: Long) {}
                override fun count(count: Long): Boolean {
                    sent += count
                    onProgress(sent.toFloat() / size)
                    return true
                }
                override fun end() {}
            })
            c.sftp.chmod(420, "$remote/video.mp4")   // 0644
            if (poster.exists()) {
                c.sftp.put(poster.absolutePath, "$remote/poster.jpg")
                c.sftp.chmod(420, "$remote/poster.jpg")
            }
            c.sftp.put(ByteArrayInputStream(share.toString(2).toByteArray()), "$remote/meta.json")
            c.sftp.chmod(420, "$remote/meta.json")
        } finally {
            c.close()
        }
        val url = "$base/v/$id"
        pubFile.writeText(JSONObject().put("id", id).put("url", url).toString())
        return url
    }

    /** Image d'affiche 1280×720 (og:image) à un instant donné (ms), ajustée sur fond noir. */
    fun posterBitmap(video: File, atMs: Long = -1L): Bitmap? {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(video.path)
            val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val t = if (atMs >= 0L) atMs * 1000L else if (ms > 2000L) 1_000_000L else 0L
            val frame = r.getFrameAtTime(t, MediaMetadataRetriever.OPTION_CLOSEST) ?: r.getFrameAtTime(0) ?: return null
            val bmp = Bitmap.createBitmap(1280, 720, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bmp)
            canvas.drawColor(Color.BLACK)
            val sc = minOf(1280f / frame.width, 720f / frame.height)
            val w = (frame.width * sc).toInt()
            val h = (frame.height * sc).toInt()
            val left = (1280 - w) / 2
            val top = (720 - h) / 2
            canvas.drawBitmap(frame, null, Rect(left, top, left + w, top + h), null)
            return bmp
        } finally {
            r.release()
        }
    }

    fun savePoster(b: Bitmap, out: File) {
        FileOutputStream(out).use { b.compress(Bitmap.CompressFormat.JPEG, 88, it) }
    }

    fun makePoster(video: File, out: File, atMs: Long = -1L) {
        val b = posterBitmap(video, atMs) ?: return
        savePoster(b, out)
    }

    private fun randomId(): String {
        val b = ByteArray(6)
        SecureRandom().nextBytes(b)
        return b.joinToString("") { String.format(Locale.ROOT, "%02x", it) }
    }

    private fun iso(): String =
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date())
}
