'use strict';
/* Pages de partage : /v/<id> = lecteur + titre + nom. Rien d'autre.
   Les fichiers arrivent par rsync dans DATA_DIR/<id>/{video.mp4,poster.jpg,meta.json}. */
const express = require('express');
const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const PORT = Number(process.env.PORT) || 4700;
const DATA_DIR = path.resolve(process.env.DATA_DIR || '/srv/share/data');
const DB_PATH = process.env.DB_PATH || '/srv/share/views.sqlite';
const BASE_URL = (process.env.BASE_URL || '').replace(/\/+$/, '');
const ID_RE = /^[a-f0-9]{12}$/;
const BOT_RE = /bot|crawl|spider|slurp|preview|facebookexternalhit|embedly|whatsapp|telegram|discord|slack|skype|linkedin|pinterest/i;

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS views (
  id TEXT PRIMARY KEY, count INTEGER NOT NULL DEFAULT 0, last_at TEXT)`);
const hit = db.prepare(`INSERT INTO views (id, count, last_at) VALUES (?, 1, datetime('now'))
  ON CONFLICT(id) DO UPDATE SET count = count + 1, last_at = datetime('now')`);

const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const readMeta = id => { try { return JSON.parse(fs.readFileSync(path.join(DATA_DIR, id, 'meta.json'), 'utf8')); } catch { return null; } };

function page({ id, title, author, base }) {
  const t = esc(title), a = esc(author || '');
  const video = `${base}/media/${id}/video.mp4`, poster = `${base}/media/${id}/poster.jpg`;
  return `<!doctype html>
<html lang="fr"><head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${t}</title>
<meta name="robots" content="noindex">
<meta property="og:type" content="video.other">
<meta property="og:title" content="${t}">
<meta property="og:url" content="${base}/v/${id}">
<meta property="og:image" content="${poster}">
<meta property="og:image:width" content="1280">
<meta property="og:image:height" content="720">
<meta property="og:video" content="${video}">
<meta property="og:video:type" content="video/mp4">
<meta name="twitter:card" content="summary_large_image">
<style>
:root{color-scheme:dark light;--bg:#000;--fg:#f5f5f5;--mut:#8e8e93}
@media (prefers-color-scheme:light){:root{--bg:#fff;--fg:#0a0a0a;--mut:#6b6b70}}
*{box-sizing:border-box}
html,body{margin:0;background:var(--bg);color:var(--fg)}
body{min-height:100vh;display:grid;place-items:center;
  font-family:Inter,"Helvetica Neue",Helvetica,Arial,system-ui,sans-serif;-webkit-font-smoothing:antialiased}
main{width:min(1100px,100%);padding:28px 16px 40px}
video{display:block;width:100%;aspect-ratio:16/9;background:#000;border-radius:4px}
h1{margin:26px 0 10px;font-weight:800;font-size:clamp(1.5rem,3.4vw,2.2rem);line-height:1.1;letter-spacing:-.025em}
p{margin:0;font:500 .74rem/1 ui-monospace,"SF Mono",Menlo,Consolas,monospace;
  text-transform:uppercase;letter-spacing:.2em;color:var(--mut)}
</style>
</head><body><main>
<video controls playsinline preload="metadata" poster="/media/${id}/poster.jpg" src="/media/${id}/video.mp4"></video>
<h1>${t}</h1>
${a ? `<p>${a}</p>` : ''}
</main></body></html>`;
}

const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 'loopback');

app.get('/v/:id', (req, res) => {
  const { id } = req.params;
  const meta = ID_RE.test(id) && readMeta(id);
  if (!meta) return res.status(404).type('text').send('Not found');
  if (req.method === 'GET' && !BOT_RE.test(req.get('user-agent') || '')) hit.run(id);
  const base = BASE_URL || `${req.protocol}://${req.get('host')}`;
  res.set({ 'Cache-Control': 'no-store', 'X-Robots-Tag': 'noindex' })
    .type('html').send(page({ id, title: meta.title || 'Sans titre', author: meta.author, base }));
});

// Seuls ces deux fichiers sont servis (sendFile gère les requêtes Range pour la vidéo).
app.get('/media/:id/:file', (req, res) => {
  const { id, file } = req.params;
  if (!ID_RE.test(id) || !['video.mp4', 'poster.jpg'].includes(file)) return res.status(404).end();
  res.set('Cache-Control', 'public, max-age=3600');
  res.sendFile(path.join(DATA_DIR, id, file), err => { if (err && !res.headersSent) res.status(404).end(); });
});

app.use((req, res) => res.status(404).type('text').send('Not found'));
app.listen(PORT, '127.0.0.1', () => console.log(`share sur 127.0.0.1:${PORT}, données : ${DATA_DIR}`));
