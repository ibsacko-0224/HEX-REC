package app.rec

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadataRetriever
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.text.InputFilter
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.core.content.ContextCompat
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import java.io.File
import java.io.FileInputStream

class MainActivity : Activity() {

    companion object {
        const val REQ_PERMS = 1
        const val REQ_PROJ = 2
        val C_BG = 0xFF16171A.toInt()
        val C_PANEL = 0xFF34353B.toInt()
        val C_FG = 0xFFECEBE7.toInt()
        val C_MUT = 0xFF9A978F.toInt()
        val C_ACC = 0xFF7AA2FF.toInt()
        val C_OK = 0xFF4CC38A.toInt()
        val C_ERR = 0xFFFF5A5A.toInt()
    }

    private lateinit var prefs: Prefs
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var root: FrameLayout
    private lateinit var pgRecord: ScrollView
    private lateinit var pgEdit: ScrollView
    private lateinit var pgSettings: ScrollView

    // Écran enregistrement
    private lateinit var titleIn: EditText
    private lateinit var camCb: CheckBox
    private lateinit var micCb: CheckBox
    private lateinit var startBtn: Button
    private lateinit var recStatus: TextView
    private lateinit var recentBox: LinearLayout

    // Écran montage
    private var dir: File? = null
    private var dur = 0L
    private var previewing = false
    private var rendering = false
    private var transformer: Transformer? = null
    private var publishedUrl: String? = null
    private lateinit var editTitle: TextView
    private lateinit var video: VideoView
    private lateinit var trim: TrimBar
    private lateinit var times: TextView
    private lateinit var playBtn: Button
    private lateinit var renderBtn: Button
    private lateinit var bar: ProgressBar
    private lateinit var editStatus: TextView
    private lateinit var finalBox: LinearLayout
    private lateinit var finalVideo: VideoView
    private lateinit var finalPlayBtn: Button
    private lateinit var pubBtn: Button
    private lateinit var pubStatus: TextView
    private lateinit var urlText: TextView
    private lateinit var copyBtn: Button

    // Écran réglages
    private val fieldViews = LinkedHashMap<String, EditText>()
    private lateinit var settingsStatus: TextView

    /* ---------- cycle de vie ---------- */

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        root = FrameLayout(this)
        setContentView(root)
        buildRecord()
        buildEdit()
        buildSettings()
        root.addView(pgRecord)
        root.addView(pgEdit)
        root.addView(pgSettings)
        show(pgRecord)
        handleIntent(intent)
        ui.post(tick)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        refreshRecordUi()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        transformer?.cancel()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (pgRecord.visibility != View.VISIBLE) leaveToRecord() else super.onBackPressed()
    }

    private fun handleIntent(i: Intent?) {
        val name = i?.getStringExtra(RecorderService.EXTRA_OPEN) ?: return
        i?.removeExtra(RecorderService.EXTRA_OPEN)
        val d = File(Store.root(this), name)
        if (d.isDirectory && File(d, "original.mp4").exists()) openEditor(d)
    }

    private val tick = object : Runnable {
        override fun run() {
            if (pgEdit.visibility == View.VISIBLE && video.isPlaying) {
                val p = video.currentPosition.toLong()
                trim.position = p
                if (previewing && p >= trim.end) {
                    video.pause()
                    video.seekTo(trim.end.toInt())
                    previewing = false
                    playBtn.text = "Lecture"
                }
                trim.invalidate()
            }
            ui.postDelayed(this, 60)
        }
    }

    /* ---------- petits utilitaires d'interface ---------- */

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(s: String, size: Float = 15f, color: Int = C_FG, bold: Boolean = false) =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun button(s: String, primary: Boolean = false, onClick: () -> Unit) = Button(this).apply {
        text = s
        isAllCaps = false
        setTextColor(if (primary) 0xFF0D1220.toInt() else C_FG)
        background = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(if (primary) C_ACC else C_PANEL)
        }
        setPadding(dp(14), dp(10), dp(14), dp(10))
        setOnClickListener { onClick() }
    }

    private fun LinearLayout.add(v: View, top: Int = 10, h: Int = ViewGroup.LayoutParams.WRAP_CONTENT): View {
        addView(v, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h).apply { topMargin = dp(top) })
        return v
    }

    private fun row(vararg v: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        v.forEachIndexed { i, x ->
            addView(x, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                if (i > 0) leftMargin = dp(8)
            })
        }
    }

    private fun column() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

    private fun page(c: LinearLayout) = ScrollView(this).apply {
        setBackgroundColor(C_BG)
        c.setPadding(dp(18), dp(24), dp(18), dp(40))
        addView(c)
    }

    private fun videoFrame(v: VideoView, heightDp: Int): FrameLayout = FrameLayout(this).apply {
        setBackgroundColor(0xFF000000.toInt())
        addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
        minimumHeight = dp(heightDp)
    }

    private fun show(p: View) {
        listOf<View>(pgRecord, pgEdit, pgSettings).forEach { it.visibility = if (it === p) View.VISIBLE else View.GONE }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun status(t: TextView, msg: String, color: Int = C_MUT) {
        t.text = msg
        t.setTextColor(color)
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    /* ---------- écran 1 : enregistrer ---------- */

    private fun buildRecord() {
        val c = column()
        c.add(label("Rec", 26f, bold = true), 0)
        c.add(label("Enregistre l'écran avec une bulle webcam, découpe, publie.", 14f, C_MUT), 4)

        titleIn = EditText(this).apply {
            hint = "Titre de la vidéo"
            setHintTextColor(C_MUT)
            setTextColor(C_FG)
            isSingleLine = true
            filters = arrayOf(InputFilter.LengthFilter(120))
        }
        c.add(titleIn, 20)
        camCb = CheckBox(this).apply { text = "Bulle webcam (bas à gauche)"; isChecked = true; setTextColor(C_FG) }
        micCb = CheckBox(this).apply { text = "Micro"; isChecked = true; setTextColor(C_FG) }
        c.add(camCb, 8)
        c.add(micCb, 0)

        startBtn = button("Démarrer l'enregistrement", true) { onStartClicked() }
        c.add(startBtn, 14)
        recStatus = label("", 14f, C_MUT)
        c.add(recStatus, 10)

        c.add(label("Récents", 16f, bold = true), 26)
        recentBox = column()
        c.add(recentBox, 6)
        c.add(button("Réglages de publication") { show(pgSettings) }, 26)
        pgRecord = page(c)
    }

    private fun refreshRecordUi() {
        if (RecorderService.running) {
            startBtn.text = "Arrêter l'enregistrement"
            status(recStatus, "Enregistrement en cours. Utilise aussi la notification « Arrêter ».", C_ERR)
        } else {
            startBtn.text = "Démarrer l'enregistrement"
            if (recStatus.currentTextColor == C_ERR) status(recStatus, "")
        }
        recentBox.removeAllViews()
        val list = Store.list(this)
        if (list.isEmpty()) recentBox.add(label("Aucun enregistrement pour l'instant.", 14f, C_MUT), 4)
        for (d in list.take(15)) {
            val meta = Store.readMeta(d)
            val tag = when {
                File(d, "publish.json").exists() -> " · publié"
                File(d, "final.mp4").exists() -> " · rendu"
                else -> ""
            }
            val item = label(meta.optString("title", d.name) + "\n" + d.name.take(10) + tag, 15f).apply {
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { openEditor(d) }
            }
            recentBox.add(item, 0)
        }
    }

    private fun onStartClicked() {
        if (RecorderService.running) {
            startService(Intent(this, RecorderService::class.java).setAction(RecorderService.ACTION_STOP))
            return
        }
        val cam = camCb.isChecked
        val mic = micCb.isChecked
        if (cam && !Settings.canDrawOverlays(this)) {
            toast("Autorise « Affichage par-dessus les autres applis » pour la bulle webcam, puis reviens.")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val need = mutableListOf<String>()
        if (cam && !granted(Manifest.permission.CAMERA)) need += Manifest.permission.CAMERA
        if (mic && !granted(Manifest.permission.RECORD_AUDIO)) need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), REQ_PERMS)
            return
        }
        askProjection()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERMS) askProjection()   // le service désactive ce qui a été refusé
    }

    @Suppress("DEPRECATION")
    private fun askProjection() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJ)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PROJ) return
        if (resultCode != RESULT_OK || data == null) {
            status(recStatus, "Capture d'écran refusée.", C_ERR)
            return
        }
        val i = Intent(this, RecorderService::class.java)
            .setAction(RecorderService.ACTION_START)
            .putExtra(RecorderService.EXTRA_CODE, resultCode)
            .putExtra(RecorderService.EXTRA_DATA, data)
            .putExtra(RecorderService.EXTRA_TITLE, titleIn.text.toString().trim())
            .putExtra(RecorderService.EXTRA_CAM, camCb.isChecked)
            .putExtra(RecorderService.EXTRA_MIC, micCb.isChecked)
        ContextCompat.startForegroundService(this, i)
        status(recStatus, "Début dans 3 s. Ouvre l'appli à montrer.", C_ERR)
        ui.postDelayed({ moveTaskToBack(true) }, 600)
    }

    /* ---------- écran 2 : montage + publication ---------- */

    private fun buildEdit() {
        val c = column()
        c.add(button("← Retour") { leaveToRecord() }, 0)
        editTitle = label("", 19f, bold = true)
        c.add(editTitle, 14)

        video = VideoView(this)
        c.add(videoFrame(video, 360), 10, dp(360))

        trim = TrimBar(this)
        trim.onDrag = { which ->
            val t = when (which) { 1 -> trim.start; 2 -> trim.end; else -> trim.position }
            video.pause()
            previewing = false
            playBtn.text = "Lecture"
            video.seekTo(t.toInt())
            updateTimes()
        }
        c.add(trim, 8)
        times = label("", 13f, C_MUT)
        c.add(times, 0)

        playBtn = button("Lecture") { togglePlay() }
        val setIn = button("Entrée ici") {
            trim.start = minOf(video.currentPosition.toLong(), trim.end - 200).coerceAtLeast(0L)
            trim.invalidate(); updateTimes()
        }
        val setOut = button("Sortie ici") {
            trim.end = maxOf(video.currentPosition.toLong(), trim.start + 200).coerceAtMost(dur)
            trim.invalidate(); updateTimes()
        }
        val prev = button("Prévisualiser") {
            previewing = true
            video.seekTo(trim.start.toInt())
            video.start()
            playBtn.text = "Pause"
        }
        c.add(row(playBtn, prev), 10)
        c.add(row(setIn, setOut), 8)

        renderBtn = button("Rendre en MP4 1080p", true) { render() }
        c.add(renderBtn, 16)
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        c.add(bar, 10)
        editStatus = label("", 14f, C_MUT)
        c.add(editStatus, 6)

        finalBox = column()
        finalBox.add(label("Rendu final", 17f, bold = true), 0)
        finalVideo = VideoView(this)
        finalBox.add(videoFrame(finalVideo, 300), 10, dp(300))
        finalPlayBtn = button("Lecture") {
            if (finalVideo.isPlaying) { finalVideo.pause(); finalPlayBtn.text = "Lecture" }
            else { finalVideo.start(); finalPlayBtn.text = "Pause" }
        }
        finalVideo.setOnCompletionListener { finalPlayBtn.text = "Lecture" }
        pubBtn = button("Publier", true) { publish() }
        finalBox.add(row(finalPlayBtn, pubBtn), 10)
        finalBox.add(button("Enregistrer dans la galerie") { exportToGallery() }, 8)
        pubStatus = label("", 14f, C_MUT)
        finalBox.add(pubStatus, 10)
        urlText = label("", 15f, C_ACC, bold = true).apply {
            setOnClickListener { publishedUrl?.let { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it))) } }
        }
        finalBox.add(urlText, 6)
        copyBtn = button("Copier le lien") { publishedUrl?.let { copyLink(it) } }
        finalBox.add(copyBtn, 8)
        c.add(finalBox, 26)
        finalBox.visibility = View.GONE

        pgEdit = page(c)
    }

    private fun updateTimes() {
        times.text = "Entrée ${Store.fmt(trim.start)}    Durée ${Store.fmt(trim.end - trim.start)}    Sortie ${Store.fmt(trim.end)}"
    }

    private fun togglePlay() {
        if (video.isPlaying) {
            video.pause(); previewing = false; playBtn.text = "Lecture"
        } else {
            video.start(); playBtn.text = "Pause"
        }
    }

    private fun openEditor(d: File) {
        dir = d
        val meta = Store.readMeta(d)
        dur = meta.optLong("durationMs", 0L)
        previewing = false
        editTitle.text = meta.optString("title", d.name)
        status(editStatus, "")
        bar.visibility = View.GONE
        renderBtn.isEnabled = true
        playBtn.text = "Lecture"

        video.stopPlayback()
        video.setOnPreparedListener { mp ->
            if (dur <= 0L) dur = mp.duration.toLong()
            trim.duration = dur
            trim.start = 0L
            trim.end = dur
            trim.position = 0L
            trim.invalidate()
            updateTimes()
            video.seekTo(1)
        }
        video.setOnCompletionListener { playBtn.text = "Lecture"; previewing = false }
        video.setVideoURI(Uri.fromFile(File(d, "original.mp4")))

        if (File(d, "final.mp4").exists()) showFinal(d) else finalBox.visibility = View.GONE
        show(pgEdit)
    }

    private fun leaveToRecord() {
        video.stopPlayback()
        finalVideo.stopPlayback()
        show(pgRecord)
        refreshRecordUi()
    }

    private fun target(w: Int, h: Int): Pair<Int, Int> {
        // 1080p sans bandes noires : le petit côté fait 1080 px, le ratio est conservé.
        fun even(v: Float) = Math.round(v) and 1.inv()
        return if (h >= w) Pair(1080, even(h * 1080f / w)) else Pair(even(w * 1080f / h), 1080)
    }

    private fun render() {
        val d = dir ?: return
        if (rendering) return
        val src = File(d, "original.mp4")
        val tmp = File(d, ".final.tmp.mp4")
        tmp.delete()

        var w = 1080
        var h = 1920
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(src.path)
            w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: w
            h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: h
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
        } catch (e: Exception) {
        } finally {
            r.release()
        }
        val (tw, th) = target(w, h)

        video.pause()
        playBtn.text = "Lecture"
        val clip = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(trim.start)
            .setEndPositionMs(trim.end)
            .build()
        val item = MediaItem.Builder().setUri(Uri.fromFile(src)).setClippingConfiguration(clip).build()
        val effects = Effects(
            emptyList<AudioProcessor>(),
            listOf<Effect>(Presentation.createForWidthAndHeight(tw, th, Presentation.LAYOUT_SCALE_TO_FIT))
        )
        val edited = EditedMediaItem.Builder(item).setEffects(effects).build()

        val t = Transformer.Builder(this)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    rendering = false
                    val fin = File(d, "final.mp4")
                    fin.delete()
                    tmp.renameTo(fin)
                    status(editStatus, "Rendu terminé. Création de l'affiche…")
                    Thread {
                        try { Publisher.makePoster(fin, File(d, "poster.jpg")) } catch (e: Exception) { }
                        ui.post {
                            bar.visibility = View.GONE
                            renderBtn.isEnabled = true
                            status(editStatus, "Rendu terminé : ${tw}×${th}, H.264.", C_OK)
                            showFinal(d)
                        }
                    }.start()
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    rendering = false
                    tmp.delete()
                    bar.visibility = View.GONE
                    renderBtn.isEnabled = true
                    status(editStatus, "Échec du rendu : ${exportException.message}", C_ERR)
                }
            })
            .build()
        transformer = t
        rendering = true
        renderBtn.isEnabled = false
        bar.progress = 0
        bar.visibility = View.VISIBLE
        status(editStatus, "Rendu en cours… garde l'appli ouverte.")
        t.start(edited, tmp.absolutePath)

        val holder = ProgressHolder()
        ui.postDelayed(object : Runnable {
            override fun run() {
                if (!rendering) return
                val s = t.getProgress(holder)
                if (s != Transformer.PROGRESS_STATE_NOT_STARTED) bar.progress = holder.progress
                ui.postDelayed(this, 300)
            }
        }, 300)
    }

    private fun showFinal(d: File) {
        finalBox.visibility = View.VISIBLE
        finalVideo.stopPlayback()
        finalPlayBtn.text = "Lecture"
        finalVideo.setOnPreparedListener { finalVideo.seekTo(1) }
        finalVideo.setVideoURI(Uri.fromFile(File(d, "final.mp4")))
        pubBtn.isEnabled = true
        status(pubStatus, if (prefs.configured()) "" else "Configure la publication dans les réglages (écran d'accueil).")
        publishedUrl = try { org.json.JSONObject(File(d, "publish.json").readText()).getString("url") } catch (e: Exception) { null }
        urlText.text = publishedUrl ?: ""
        urlText.visibility = if (publishedUrl != null) View.VISIBLE else View.GONE
        copyBtn.visibility = urlText.visibility
    }

    private fun copyLink(url: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("lien", url))
    }

    private fun publish() {
        val d = dir ?: return
        if (!prefs.configured()) {
            toast("Renseigne d'abord les réglages de publication.")
            show(pgSettings)
            return
        }
        val title = Store.readMeta(d).optString("title", d.name)
        pubBtn.isEnabled = false
        status(pubStatus, "Envoi vers le serveur…")
        Thread {
            try {
                val url = Publisher.publish(prefs, d, title) { f ->
                    ui.post { status(pubStatus, "Envoi… ${(f * 100).toInt().coerceIn(0, 100)} %") }
                }
                ui.post {
                    publishedUrl = url
                    urlText.text = url
                    urlText.visibility = View.VISIBLE
                    copyBtn.visibility = View.VISIBLE
                    copyLink(url)
                    status(pubStatus, "Publié. Lien copié dans le presse-papiers.", C_OK)
                    pubBtn.isEnabled = true
                }
            } catch (e: Exception) {
                ui.post {
                    status(pubStatus, "Échec : ${e.message}", C_ERR)
                    pubBtn.isEnabled = true
                }
            }
        }.start()
    }

    private fun exportToGallery() {
        val d = dir ?: return
        val f = File(d, "final.mp4")
        if (!f.exists()) return
        try {
            val v = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, d.name + ".mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Recordings")
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
                ?: throw IllegalStateException("MediaStore indisponible")
            contentResolver.openOutputStream(uri)?.use { out -> FileInputStream(f).use { it.copyTo(out) } }
            toast("Enregistré dans Films/Recordings")
        } catch (e: Exception) {
            toast("Export impossible : ${e.message}")
        }
    }

    /* ---------- écran 3 : réglages ---------- */

    private fun buildSettings() {
        val c = column()
        c.add(button("← Retour") { show(pgRecord) }, 0)
        c.add(label("Publication (SFTP)", 19f, bold = true), 14)
        c.add(label("L'appli envoie la vidéo sur ton VPS par SFTP. Rien d'autre ne sort du téléphone.", 13f, C_MUT), 4)

        data class F(val key: String, val label: String, val hint: String, val kind: Int, val multi: Boolean = false)
        val text = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        val pass = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        val fields = listOf(
            F("author", "Ton nom (affiché sur la page)", "Ton Nom", InputType.TYPE_CLASS_TEXT),
            F("baseUrl", "URL de partage", "https://share.example.com", text),
            F("host", "Serveur SSH", "ton-vps.example.com", text),
            F("port", "Port", "22", InputType.TYPE_CLASS_NUMBER),
            F("user", "Utilisateur SSH", "share", text),
            F("dataDir", "Dossier distant", "/srv/share/data", text),
            F("password", "Mot de passe SSH (si pas de clé)", "", pass),
            F("key", "Clé privée (optionnel, RSA/ECDSA recommandé)", "-----BEGIN OPENSSH PRIVATE KEY-----", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE, true),
            F("passphrase", "Mot de passe de la clé (si chiffrée)", "", pass)
        )
        for (f in fields) {
            c.add(label(f.label, 13f, C_MUT), 14)
            val e = EditText(this).apply {
                hint = f.hint
                setHintTextColor(0xFF5E5C57.toInt())
                setTextColor(C_FG)
                inputType = f.kind
                setText(prefs.get(f.key))
                if (f.multi) { minLines = 4; maxLines = 8; gravity = Gravity.TOP or Gravity.START; textSize = 12f } else isSingleLine = true
            }
            fieldViews[f.key] = e
            c.add(e, 2)
        }
        settingsStatus = label("", 14f, C_MUT)
        c.add(button("Enregistrer", true) { saveSettings(); status(settingsStatus, "Réglages enregistrés.", C_OK) }, 20)
        c.add(button("Tester la connexion") { testConnection() }, 8)
        c.add(button("Oublier la clé du serveur") { prefs.put("known_hosts", ""); status(settingsStatus, "Clé du serveur oubliée.") }, 8)
        c.add(settingsStatus, 10)
        pgSettings = page(c)
    }

    private fun saveSettings() {
        for ((k, e) in fieldViews) prefs.put(k, e.text.toString().trim().let { if (k == "password" || k == "passphrase") e.text.toString() else it })
    }

    private fun testConnection() {
        saveSettings()
        status(settingsStatus, "Connexion…")
        Thread {
            val msg = try { Publisher.test(prefs) to C_OK } catch (e: Exception) { ("Échec : ${e.message}") to C_ERR }
            ui.post { status(settingsStatus, msg.first, msg.second) }
        }.start()
    }
}
