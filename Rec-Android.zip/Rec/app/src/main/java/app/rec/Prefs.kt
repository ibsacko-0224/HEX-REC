package app.rec

import android.content.Context

/** Réglages de publication (stockés dans le stockage privé de l'application). */
class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun get(k: String): String = sp.getString(k, "") ?: ""
    fun put(k: String, v: String) { sp.edit().putString(k, v).apply() }

    fun configured(): Boolean =
        get("baseUrl").startsWith("http") && get("host").isNotBlank() && get("user").isNotBlank() &&
            get("dataDir").startsWith("/") && (get("password").isNotEmpty() || get("key").isNotBlank())
}
