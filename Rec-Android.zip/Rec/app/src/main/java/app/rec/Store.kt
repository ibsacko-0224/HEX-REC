package app.rec

import android.content.Context
import android.os.Environment
import org.json.JSONObject
import java.io.File
import java.text.Normalizer
import java.util.Calendar
import java.util.Locale

/** Dossiers d'enregistrement : <Movies de l'app>/Recordings/AAAA-MM-JJ-<titre>/ */
object Store {
    fun root(ctx: Context): File =
        File(ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: ctx.filesDir, "Recordings").apply { mkdirs() }

    fun slug(s: String): String {
        val n = Normalizer.normalize(s, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .lowercase(Locale.ROOT)
            .replace(Regex("[^a-z0-9]+"), "-")
            .trim('-')
        return n.take(60).trim('-').ifEmpty { "sans-titre" }
    }

    fun newFolder(ctx: Context, title: String): File {
        val c = Calendar.getInstance()
        val base = String.format(
            Locale.ROOT, "%04d-%02d-%02d-%s",
            c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH), slug(title)
        )
        for (i in 1..1000) {
            val f = File(root(ctx), if (i == 1) base else "$base-$i")
            if (f.mkdirs()) return f
        }
        throw IllegalStateException("Impossible de créer le dossier d'enregistrement")
    }

    fun readMeta(dir: File): JSONObject =
        try { JSONObject(File(dir, "meta.json").readText()) } catch (e: Exception) { JSONObject() }

    fun writeMeta(dir: File, o: JSONObject) {
        File(dir, "meta.json").writeText(o.toString(2))
    }

    fun list(ctx: Context): List<File> =
        root(ctx).listFiles { f -> f.isDirectory && File(f, "original.mp4").exists() }
            ?.sortedByDescending { it.name } ?: emptyList()

    fun fmt(ms: Long): String {
        val s = ms / 1000.0
        val m = (s / 60).toInt()
        return String.format(Locale.US, "%d:%04.1f", m, s - m * 60)
    }
}
