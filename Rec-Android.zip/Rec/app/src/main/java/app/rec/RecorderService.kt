package app.rec

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Outline
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaMetadataRetriever
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.ContextThemeWrapper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import androidx.lifecycle.LifecycleService
import org.json.JSONObject
import java.io.File

/**
 * Enregistre l'écran (MediaProjection + MediaRecorder, H.264/AAC) et affiche une bulle
 * webcam ronde en bas à gauche. La bulle est une fenêtre système : elle est donc
 * capturée avec l'écran, sans composition supplémentaire.
 */
class RecorderService : LifecycleService() {

    companion object {
        const val ACTION_START = "app.rec.START"
        const val ACTION_STOP = "app.rec.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_TITLE = "title"
        const val EXTRA_CAM = "cam"
        const val EXTRA_MIC = "mic"
        const val EXTRA_OPEN = "open"
        private const val CH_REC = "rec"
        private const val CH_DONE = "done"
        private const val ID_REC = 1
        private const val ID_DONE = 2
        private const val COUNTDOWN_MS = 3000L

        @Volatile
        var running = false
    }

    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var recorder: MediaRecorder? = null
    private var display: VirtualDisplay? = null
    private var bubble: View? = null
    private var dir: File? = null
    private var title = ""
    private var wantCam = false
    private var wantMic = false
    private var stopping = false
    private var vw = 0
    private var vh = 0
    private var dpi = 0

    private val wm: WindowManager by lazy { getSystemService(WindowManager::class.java) }
    private val nm: NotificationManager by lazy { getSystemService(NotificationManager::class.java) }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        when (intent?.action) {
            ACTION_START -> if (!running) start(intent)
            ACTION_STOP -> stopRecording()
            else -> stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun granted(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun start(i: Intent) {
        running = true
        title = (i.getStringExtra(EXTRA_TITLE) ?: "").ifBlank { "Sans titre" }
        wantMic = i.getBooleanExtra(EXTRA_MIC, false) && granted(Manifest.permission.RECORD_AUDIO)
        wantCam = i.getBooleanExtra(EXTRA_CAM, false) && granted(Manifest.permission.CAMERA) &&
            Settings.canDrawOverlays(this)
        createChannels()

        var types = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        if (wantCam) types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
        if (wantMic) types = types or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        try {
            startForeground(ID_REC, recNotification("Début dans 3 s…"), types)
        } catch (e: Exception) {
            Toast.makeText(this, "Démarrage impossible : ${e.message}", Toast.LENGTH_LONG).show()
            running = false
            stopping = true
            stopSelf()
            return
        }

        try {
            val data = IntentCompat.getParcelableExtra(i, EXTRA_DATA, Intent::class.java)
                ?: throw IllegalStateException("Autorisation de capture manquante")
            val mpm = getSystemService(MediaProjectionManager::class.java)
            val proj = mpm.getMediaProjection(i.getIntExtra(EXTRA_CODE, 0), data)
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { main.post { stopRecording() } }
            }, main)
            projection = proj

            val d = Store.newFolder(this, title)
            dir = d
            Store.writeMeta(d, JSONObject().put("title", title).put("createdAt", System.currentTimeMillis()))

            if (wantCam) showBubble()
            main.postDelayed({ begin() }, COUNTDOWN_MS)
        } catch (e: Exception) {
            fail(e)
        }
    }

    private fun begin() {
        if (stopping) return
        try {
            val rec = prepareRecorder()
            recorder = rec
            display = projection!!.createVirtualDisplay(
                "rec", vw, vh, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                rec.surface, null, null
            )
            rec.start()
            nm.notify(ID_REC, recNotification("Enregistrement en cours"))
        } catch (e: Exception) {
            fail(e)
        }
    }

    private fun prepareRecorder(): MediaRecorder {
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(dm)
        dpi = dm.densityDpi
        val out = File(dir, "original.mp4")
        var last: Exception? = null
        for (target in intArrayOf(1080, 720, 480)) {
            val sc = minOf(1f, target.toFloat() / minOf(dm.widthPixels, dm.heightPixels))
            val w = (dm.widthPixels * sc).toInt() and 1.inv()
            val h = (dm.heightPixels * sc).toInt() and 1.inv()
            val r = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            try {
                if (wantMic) r.setAudioSource(MediaRecorder.AudioSource.MIC)
                r.setVideoSource(MediaRecorder.VideoSource.SURFACE)
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                r.setOutputFile(out)
                r.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
                if (wantMic) {
                    r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                    r.setAudioEncodingBitRate(128_000)
                    r.setAudioSamplingRate(44100)
                }
                r.setVideoSize(w, h)
                r.setVideoFrameRate(30)
                r.setVideoEncodingBitRate(minOf(12_000_000, w * h * 4))
                r.prepare()
                vw = w
                vh = h
                return r
            } catch (e: Exception) {
                last = e
                try { r.release() } catch (x: Exception) { }
            }
        }
        throw last ?: IllegalStateException("Encodeur vidéo indisponible")
    }

    /** Bulle ronde (aperçu de la caméra frontale), glissable, en bas à gauche. */
    private fun showBubble() {
        val ctx = ContextThemeWrapper(this, R.style.AppTheme)
        val density = resources.displayMetrics.density
        val size = (150 * density).toInt()
        val ring = (3 * density).toInt()

        val pv = PreviewView(ctx).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FILL_CENTER
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setOval(0, 0, view.width, view.height)
                }
            }
            clipToOutline = true
        }
        val box = FrameLayout(ctx).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFFFFFFFF.toInt())
            }
            setPadding(ring, ring, ring, ring)
            addView(pv, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            x = (16 * density).toInt()
            y = (48 * density).toInt()
        }
        box.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f
            var sy = 0f
            var ox = 0
            var oy = 0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                    MotionEvent.ACTION_MOVE -> {
                        lp.x = ox + (e.rawX - sx).toInt()
                        lp.y = oy - (e.rawY - sy).toInt()
                        try { wm.updateViewLayout(v, lp) } catch (x: Exception) { }
                    }
                }
                return true
            }
        })
        wm.addView(box, lp)
        bubble = box

        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().build()
                preview.setSurfaceProvider(pv.surfaceProvider)
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, preview)
            } catch (e: Exception) {
                Toast.makeText(this, "Caméra indisponible : ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun stopRecording() {
        if (stopping) return
        stopping = true
        main.removeCallbacksAndMessages(null)
        bubble?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        bubble = null

        var ok = false
        val rec = recorder
        if (rec != null) {
            try { rec.stop(); ok = true } catch (e: RuntimeException) { }
            try { rec.release() } catch (e: Exception) { }
        }
        recorder = null
        try { display?.release() } catch (e: Exception) { }
        display = null
        try { projection?.stop() } catch (e: Exception) { }
        projection = null

        val d = dir
        if (d != null) {
            if (ok) {
                finishMeta(d)
                notifyDone(d)
            } else {
                d.deleteRecursively()
                Toast.makeText(this, "Enregistrement annulé ou trop court", Toast.LENGTH_LONG).show()
            }
        }
        running = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun fail(e: Exception) {
        Toast.makeText(this, "Enregistrement impossible : ${e.message}", Toast.LENGTH_LONG).show()
        stopRecording()
    }

    private fun finishMeta(d: File) {
        val r = MediaMetadataRetriever()
        val ms = try {
            r.setDataSource(File(d, "original.mp4").path)
            r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            0L
        } finally {
            r.release()
        }
        Store.writeMeta(d, Store.readMeta(d).put("durationMs", ms))
    }

    private fun createChannels() {
        nm.createNotificationChannel(NotificationChannel(CH_REC, "Enregistrement", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Enregistrement terminé", NotificationManager.IMPORTANCE_DEFAULT))
    }

    private fun recNotification(text: String): Notification {
        val stop = PendingIntent.getService(
            this, 0, Intent(this, RecorderService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val action = Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "Arrêter", stop).build()
        return Notification.Builder(this, CH_REC)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title.ifBlank { "Rec" })
            .setContentText(text)
            .setOngoing(true)
            .addAction(action)
            .build()
    }

    private fun notifyDone(d: File) {
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java).putExtra(EXTRA_OPEN, d.name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        nm.notify(
            ID_DONE,
            Notification.Builder(this, CH_DONE)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("Enregistrement terminé")
                .setContentText("Touche pour découper et publier")
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
        )
    }

    override fun onDestroy() {
        if (!stopping) stopRecording()
        super.onDestroy()
    }
}
