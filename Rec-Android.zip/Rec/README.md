# Rec pour Android

Enregistreur d'écran avec bulle webcam ronde, découpe entrée/sortie, rendu MP4 H.264 1080p et publication en un clic sur ton VPS (pages `/v/<id>`).

Sans compte ni télémétrie. La seule connexion réseau est l'envoi SFTP vers **ton** serveur.

## Utilisation

1. **Enregistrer** : titre, option webcam et micro, puis *Démarrer*. L'appli passe en arrière-plan, un décompte de 3 s se déroule, puis l'enregistrement commence. La bulle webcam (bas à gauche, déplaçable avec le doigt) est capturée avec l'écran. Arrête avec la notification **Arrêter**.
2. **Montage** : touche la notification « Enregistrement terminé » (ou un élément de « Récents »). Glisse les poignées de la chronologie, ou place la lecture et touche *Entrée ici* / *Sortie ici*. *Prévisualiser* joue seulement la sélection. *Rendre en MP4 1080p* produit `final.mp4` (le petit côté fait 1080 px, ratio conservé, donc 1080×1920 en portrait).
3. **Publier** : envoie le MP4, l'affiche et les infos sur le VPS, puis copie `https://…/v/<id>` dans le presse-papiers.

## Autorisations demandées

| Autorisation | Pourquoi |
|---|---|
| Capture d'écran (boîte de dialogue Android) | demandée à chaque enregistrement |
| Caméra | bulle webcam |
| Micro | voix |
| Affichage par-dessus les autres applis | bulle webcam visible pendant l'enregistrement |
| Notifications | bouton Arrêter et fin d'enregistrement |

Si la caméra ou le micro sont refusés, l'enregistrement se fait sans.

## Réglages de publication

Sur l'écran d'accueil : *Réglages de publication*.

- **URL de partage** : `https://share.example.com`
- **Serveur / port / utilisateur SSH** : ex. `ton-vps.example.com`, `22`, `share`
- **Dossier distant** : `/srv/share/data` (le même que l'appli de partage du VPS)
- **Authentification** : mot de passe SSH, ou clé privée collée en entier.
  - Pour une clé, préfère RSA ou ECDSA : `ssh-keygen -t rsa -b 4096 -m PEM`. Les clés **ed25519** peuvent ne pas être lues sur Android.
- *Tester la connexion* vérifie tout avant le premier envoi.

La clé du serveur est mémorisée à la première connexion (TOFU), puis vérifiée. Si elle change, l'envoi est refusé : *Oublier la clé du serveur* si le changement est normal.

Côté VPS, utilise l'appli de partage + Caddy de la version bureau (dossier `vps/share`). Le format reçu est identique : `<id>/video.mp4`, `poster.jpg`, `meta.json`.

## Fichiers

Dans `Android/data/app.rec/files/Movies/Recordings/AAAA-MM-JJ-<titre>/` :

`original.mp4` (enregistrement brut), `final.mp4` (rendu), `poster.jpg`, `meta.json`, `publish.json`.

Le bouton *Enregistrer dans la galerie* copie le rendu dans Films/Recordings.

## Compiler l'APK avec GitHub

1. Crée un dépôt GitHub.
2. Envoie à la racine du dépôt le fichier `Rec-Android.zip` (tel quel, sans le dézipper).
3. Ajoute le fichier `build.yml` dans `.github/workflows/build.yml`.
4. Onglet **Actions** → *Construire l'APK Rec* → *Run workflow* (il se lance aussi à chaque push sur `main`).
5. L'APK apparaît dans **Releases** (`app-debug.apk`), prêt à installer. Autorise l'installation depuis ta source (Chrome ou Fichiers).

Pour compiler à la main : `gradle assembleDebug` dans le dossier `Rec/` (JDK 17, Android SDK 34, Gradle 8.9).

## Limites

- Android 11 minimum.
- Le son est celui du **micro** seulement : l'audio interne des applis n'est pas capturé.
- Ne fais pas pivoter l'écran pendant l'enregistrement : la taille est fixée au départ.
- Les applis qui bloquent la capture (banque, DRM) apparaissent en noir.
- Le rendu 1080p se fait sur le téléphone : garde l'appli ouverte et branche-le pour les longues vidéos.
- Les réglages (mot de passe, clé) sont stockés dans le stockage privé de l'appli, non chiffrés.
- Le code n'a pas pu être compilé ni testé sur un appareil au moment de sa création. Si le premier build GitHub échoue, copie l'erreur du journal Actions et elle sera corrigée.
